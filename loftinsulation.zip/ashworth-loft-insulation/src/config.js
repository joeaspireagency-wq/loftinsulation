/* =====================================================================
   site.config: ALL content lives here. Reskin the template by editing this block.
   PLACEHOLDER - replace for real client: every business detail, review, price,
   result, statistic and image in this file is fictional.
   ===================================================================== */
const S = (kind, tone, x, y, size, op, dur, delay, dx, dy, rot = 0, sc = 1) =>
  ({ kind, tone, x, y, size, op, dur, delay, dx, dy, rot, sc });

const SITE = {
  ctaLabel: "Get Your Free Quote",
  ctaMicro: "Free, no obligation, no pushy sales.",

  colours: { // applied to CSS custom properties at load (see applyTheme)
    evergreen: "#0F2E24", evergreen800: "#1B4A3A", evergreen50: "#E8F0EC", evergreenDeep: "#0A2119",
    amber: "#F59E0B", amberHover: "#D98A06", amberSoft: "#FEF3C7",
    cream: "#FAF9F5", charcoal: "#111827", muted: "#4B5563", heat: "#E2693A"
  },

  business: { // PLACEHOLDER - replace for real client
    name: "Ashworth Loft Insulation", short: "Ashworth", city: "Nottingham",
    rating: 4.9, reviewCount: 212, loftsDone: "3,400+",
    blurb: "Local loft insulation from Pete Ashworth and his crew of four. Fixed prices, tidy work and honest advice."
  },
  owner: { // PLACEHOLDER - replace for real client
    name: "Pete Ashworth", yearsFitting: 16, yearsOwn: 9, crew: 4,
    line: "I'll tell you straight if you don't need it."
  },
  contact: { // PLACEHOLDER - replace for real client
    phone: "+44 7340 842540", phoneHref: "+447340842540", whatsapp: "447340842540", // PLACEHOLDER - replace for real client
    email: "hello@ashworthloft.example",
    address: ["Unit 4, Meadow Lane Trading Estate", "Nottingham NG2 0AB"],
    hours: [["Mon-Fri", "8am-6pm"], ["Sat", "9am-1pm"], ["Sun", "Closed"]]
  },

  nav: [
    { label: "Pricing", href: "#pricing" },
    { label: "Reviews", href: "#reviews" },
    { label: "FAQ", href: "#faq" }
  ],

  hero: {
    headline: "Cut your heating bills. Fixed-price loft insulation, fitted in one day.",
    sub: "A free loft check, a price in writing and a tidy one-day fit from a local Nottingham crew. If you don't need it, Pete will tell you straight.",
    bullets: ["Fixed price, in writing", "Fitted in one day", "25-year workmanship guarantee"],
    team: "Pete's team, Nottingham"
  },

  trust: [
    { icon: "star", title: "4.9 stars", text: "from 212 reviews" },
    { icon: "award", title: "25-year guarantee", text: "On our workmanship" },
    { icon: "shield", title: "Fully insured", text: "On every job" },
    { icon: "badge", title: "Accreditation", text: "Example accreditation badge" }
  ],

  why: {
    headline: "Your roof is where a lot of your heat goes.",
    // PLACEHOLDER - replace for real client (figure to verify)
    stat: "Roughly a quarter",
    statNote: "of a home's heat can be lost through an uninsulated roof.",
    fine: "Typical figure for a home with little or no loft insulation. Yours will vary.",
    body: "Heat rises. Without enough insulation above your ceiling, it keeps going, and you pay to heat the sky. A properly insulated loft keeps the warmth where you live.",
    caption: "The big arrows show heat leaving through the roof. Smaller arrows: heat also escapes through walls, windows, doors and floors.",
    benefits: [
      { icon: "pound", title: "Lower heating bills", text: "Your boiler works less to keep rooms at temperature, so you use less gas or electric." },
      { icon: "thermo", title: "Warmer rooms", text: "Top-floor rooms stop feeling like the coldest in the house, and the warmth lasts longer." },
      { icon: "drops", title: "Less condensation", text: "A warmer ceiling means fewer cold surfaces for damp air to settle on, so fewer misted windows." }
    ]
  },

  services: [
    { icon: "layers", title: "Loft insulation top-up", text: "Mineral wool laid to 270mm, the depth experts recommend." },
    { icon: "grid", title: "Loft boarding", text: "Raised boards over the insulation, so you get storage without losing warmth." },
    { icon: "box", title: "Loft clearance", text: "We move your stored boxes out and back, so you don't have to." },
    { icon: "wind", title: "Blown insulation", text: "For awkward lofts and tight corners the wool can't reach." },
    { icon: "drop", title: "Ventilation & condensation check", text: "We keep your loft breathing so it stays dry." },
    { icon: "tank", title: "Hatch, tank & pipes", text: "Insulated hatch, lagged tank and pipes, so no cold spots are left behind." }
  ],

  steps: [
    { title: "Send a photo or book a visit", text: "Snap your loft from the hatch, or book a free visit. Whichever is easier." },
    { title: "Get a fixed price in 24 hours", text: "A clear written quote. The price on it is the price you pay." },
    { title: "Fitted in one day", text: "Two installers, floors protected, waste taken away. Photos sent when we're done." }
  ],

  included: [
    "Free loft check and photo report", "Fixed price in writing", "Insulation measured to the depth quoted",
    "Eaves ventilation kept clear", "Loft hatch insulated and draught-sealed", "Floors and stairs protected",
    "All waste taken away", "Photos of the finished loft sent to you", "Installation certificate", "25-year workmanship guarantee"
  ],

  houseTypes: [
    { id: "terrace", label: "Terrace", full: "Terraced house" },
    { id: "semi", label: "Semi", full: "Semi-detached house" },
    { id: "detached", label: "Detached", full: "Detached house" },
    { id: "bungalow", label: "Bungalow", full: "Bungalow" }
  ],
  defaultHouse: "semi",
  // PLACEHOLDER - replace for real client: "from" prices as Essential / Warm & Store / Full Loft
  prices: {
    terrace: [399, 599, 949],
    semi: [499, 749, 1199],
    detached: [649, 949, 1499],
    bungalow: [549, 799, 1249]
  },
  packages: [
    { id: "essential", name: "Essential Top-up", tag: "For lofts that mainly need more wool.",
      features: ["Insulation to 270mm", "Hatch sealed", "Tank and pipes lagged", "Photo report and certificate"] },
    { id: "warm-store", name: "Warm & Store", tag: "Warmth plus usable storage.", badge: "Most popular", featured: true,
      features: ["Everything in Essential", "Raised loft boarding over the insulation"] },
    { id: "full-loft", name: "Full Loft Service", tag: "We do the lot, you lift nothing.",
      features: ["Everything in Warm & Store", "Loft clearance and refit", "Extra eaves vents", "Priority booking"] }
  ],

  guarantees: {
    title: "Our promises, in writing",
    items: [
      { icon: "pound", title: "Fixed-price promise", text: "The price on your written quote is the price you pay. No extras on the day." },
      { icon: "ruler", title: "Right-depth promise", text: "We fit the depth we quote and photograph it before we leave, so you can see it for yourself." },
      { icon: "home", title: "Tidy-home promise", text: "We protect your floors, clear up and take our waste away. If we miss anything, we come back and sort it." },
      { icon: "award", title: "25-year workmanship guarantee", text: "Every job comes with a written guarantee on our workmanship." },
      { icon: "smile", title: "Pay when you're happy", text: "No deposit. You pay once the job's done and you've checked it." }
    ],
    smallPrint: "We guarantee our workmanship and our price, not specific bill savings, because every home is different. We'll give you an honest estimate with your quote."
  },

  caseStudy: { // PLACEHOLDER - replace for real client
    title: "Example result: 1970s semi, Beeston", chip: "Fictional example",
    stats: [
      { label: "Before", value: "50mm patchy wool" },
      { label: "After", value: "270mm, even coverage" },
      { label: "Time on site", value: "One day, 2 installers" },
      { label: "Price", value: "£549 fixed, as quoted" }
    ],
    saving: { value: "Est. £310 a year", note: "(estimate based on typical figures; varies by home)" },
    quote: "I turned the thermostat down a degree and the house is still warmer.",
    cite: "Mrs Patel, Beeston"
  },

  reviews: { // PLACEHOLDER - replace for real client
    chip: "Example reviews (fictional)",
    items: [
      { name: "Sarah T.", town: "Beeston", type: "3-bed semi", text: "Pete quoted £549 and that's exactly what I paid. Two lads, one day, and they hoovered up after themselves. The back bedroom feels warmer already." },
      { name: "David & Linda R.", town: "West Bridgford", type: "Detached", text: "We were dreading the mess. There was none. Dust sheets on the stairs, tidy loft, and photos sent the same afternoon." },
      { name: "Janet H.", town: "Arnold", type: "Bungalow", text: "I'm 71 and was nervous about strangers in the loft. Pete explained everything, no pressure, and kept me updated all day." },
      { name: "Marcus W.", town: "Long Eaton", type: "Terrace", text: "Got three quotes. Ashworth wasn't the cheapest but was the only one with a fixed price in writing. No surprises." },
      { name: "Priya K.", town: "Derby", type: "1930s semi", text: "We had condensation on the bedroom windows. Pete checked the ventilation and sorted it. Much better this winter." },
      { name: "Tom B.", town: "Sherwood", type: "Landlord", text: "Used them for two rental properties. On time, tidy, certificate sent same day. Easy." }
    ]
  },

  faqs: [
    { q: "Is it actually worth the money?", a: "For most homes, yes. Loft insulation is one of the cheapest ways to cut heating costs, and we'll give you an honest estimate for your home with your quote. If your loft is already well insulated, we'll tell you, and you won't pay us a penny." },
    { q: "I already have some insulation. Do I need more?", a: "Maybe not. The recommended depth is 270mm. We measure what you have for free. If you're already there, we'll say so. If not, we top up without ripping out what's still good." },
    { q: "Will it cause damp or condensation?", a: "Done properly, no. We keep your eaves ventilation clear and add vents where needed. A ventilation and condensation check is part of every free loft check." },
    { q: "How messy is it? Do I need to be home?", a: "Very little mess. We protect floors and stairs, clear up and take all waste away. Someone needs to be in to let us in and check the finished job, but you don't have to stay in all day." },
    { q: "Will the price change on the day?", a: "No. After your free check you get a fixed price in writing. That's what you pay, and you pay when it's finished, not before." },
    { q: "How do I know you'll do a proper job?", a: "We're fully insured, the 25-year workmanship guarantee is in writing, and we send photos of the finished loft. Over 200 local customers have reviewed us, and we're happy to give you references." },
    { q: "Can I get a grant or help with the cost?", a: "You might. Some households qualify for support, and schemes change often. We'll check when we quote and tell you honestly, with no obligation either way." }
  ],
  faqAfter: "Still unsure? Get a free check and Pete will tell you straight.",

  about: {
    headline: "Hello, I'm Pete.",
    paras: [
      "I've fitted insulation for 16 years. For most of that I worked for a big contractor, and I got fed up with it. Rushed jobs. Mess left behind. Prices that crept up on the day.",
      "Nine years ago I started Ashworth Loft Insulation with a simple idea: do it properly, charge what we quoted and leave your home tidier than we found it.",
      "Today there are four of us: two installers, a surveyor and an office manager. If your loft is already fine, I'll say so, and you won't pay us a penny for that."
    ],
    facts: [["16 years", "fitting insulation"], ["9 years", "running our own firm"], ["Crew of 4", "two installers, a surveyor, an office"]]
  },

  area: {
    headline: "Local to Nottingham, out to about 25 miles.",
    text: "We cover Nottinghamshire, Derbyshire and Leicestershire. Not sure if you're in range? Ask for your free quote and Pete's team will tell you.",
    towns: ["Nottingham", "Derby", "Leicester", "Loughborough", "Mansfield", "Newark-on-Trent"]
  },

  final: { headline: "Ready for a warmer, cheaper-to-heat home?", sub: "A free loft check and a fixed price in writing. No pressure, and no deposit." },

  disclaimers: {
    pricing: "Prices are guides for a typical property. Your fixed price depends on loft size, access and existing insulation, and is confirmed in writing after your free loft check. The price on your quote is the price you pay. Pay when the job's done. No deposit.",
    footer: "Ashworth Loft Insulation is a fictional business created for demonstration. Reviews, results, prices and contact details are examples only.",
    form: "Demonstration only. Nothing you enter is sent or stored."
  },

  // Ambient shape layouts. Typed and easy to tweak: x/y are % of the section, size in px.
  // dark: cream or amber, rings/lines .10-.18, amber discs .06-.10. light: evergreen only, .04-.07.
  shapes: {
    hero: [
      S("ring", "cream", 58, 4, 300, .13, 31, -9, 40, -52, 0, 1.04),
      S("disc", "amber", 66, 38, 400, .09, 43, -21, -52, -62, 0, 1.06),
      S("line", "cream", 4, 16, 220, .16, 24, -6, 36, -46, 6),
      S("ring", "cream", 38, 78, 130, .12, 19, -11, -30, -42, 0, 1.08),
      S("curve", "cream", 12, 66, 260, .15, 37, -17, 54, -38, -5),
      S("disc", "cream", 86, 2, 220, .07, 28, -4, -40, -48, 0, 1.05),
      S("dash", "amber", 48, 12, 180, .16, 45, -30, 34, -40, 8)
    ],
    promises: [
      S("ring", "cream", 4, 8, 240, .12, 22, -7, 36, -44, 0, 1.05),
      S("disc", "amber", 74, 50, 360, .08, 34, -13, -46, -58, 0, 1.06),
      S("line", "cream", 60, 6, 240, .15, 26, -19, 40, -42, -7),
      S("curve", "cream", 8, 78, 240, .14, 40, -25, 48, -34, 5),
      S("dash", "amber", 82, 84, 160, .15, 20, -3, -34, -40, -6)
    ],
    final: [
      S("ring", "cream", 6, 14, 280, .12, 33, -15, 44, -54, 0, 1.05),
      S("disc", "amber", 62, 30, 420, .09, 41, -27, -56, -66, 0, 1.07),
      S("line", "cream", 78, 18, 200, .16, 29, -8, 32, -44, 8),
      S("ring", "cream", 82, 66, 110, .14, 23, -2, -26, -38, 0, 1.1),
      S("curve", "cream", 14, 70, 250, .15, 36, -21, 50, -36, -4),
      S("dash", "amber", 40, 8, 190, .13, 44, -33, 36, -42, 7)
    ],
    about: [
      S("ring", "evergreen", 70, 10, 260, .06, 27, -12, 34, -46, 0, 1.04),
      S("disc", "evergreen", 2, 62, 340, .05, 38, -18, 44, -56, 0, 1.05),
      S("line", "evergreen", 56, 82, 220, .06, 21, -5, 38, -40, -6)
    ],
    why: [
      S("ring", "evergreen", 4, 6, 220, .06, 25, -10, 34, -44, 0, 1.04),
      S("disc", "evergreen", 78, 54, 360, .05, 32, -16, -44, -56, 0, 1.05),
      S("curve", "evergreen", 46, 90, 240, .06, 30, -23, 46, -34, 5)
    ]
  }
};

/* Build-time style config check (stand-in for the Zod schema the full Next.js build would use). */
function validateConfig(c) {
  const errs = [];
  const need = (ok, msg) => { if (!ok) errs.push(msg); };
  need(typeof c.ctaLabel === "string" && c.ctaLabel.length > 0, "ctaLabel must be a non-empty string");
  need(c.services.length === 6, "services must have 6 items");
  need(c.packages.length === 3, "packages must have 3 items");
  need(c.guarantees.items.length === 5, "guarantees must have 5 items");
  need(c.reviews.items.length === 6, "reviews must have 6 items");
  need(c.faqs.length === 7, "faqs must have 7 items");
  c.houseTypes.forEach(h => need(Array.isArray(c.prices[h.id]) && c.prices[h.id].length === 3, `prices.${h.id} must have 3 numbers`));
  need(c.prices[c.defaultHouse] !== undefined, "defaultHouse must exist in prices");
  const durs = Object.values(c.shapes).flat().map(s => s.dur);
  need(new Set(durs).size === durs.length, "every ambient shape needs its own duration");
  Object.entries({ hero: 7, promises: 5, final: 6, about: 3, why: 3 }).forEach(([k, n]) => need(c.shapes[k].length === n, `shapes.${k} must have ${n} shapes`));
  if (errs.length) throw new Error("Invalid site config: " + errs.join("; "));
  return c;
}
