/* =====================================================================
   Illustrations + image manifest.
   PLACEHOLDER - replace for real client: every image below is an original SVG
   illustration. To swap in a real photo, set `src` (and keep width/height/alt) on
   the matching entry in IMAGES. Components only ever reference images by id.
   ===================================================================== */
const FONT = `font-family="Inter,system-ui,sans-serif"`;
const SVG_OPEN = (vb, extra = "") => `<svg viewBox="${vb}" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" ${extra}>`;

/* ---- hero: cutaway semi with 270mm of wool, installer and depth gauge (4:3) ---- */
function artHero() {
  let joists = "";
  for (let x = 225; x <= 975; x += 62) joists += `<rect x="${x}" y="430" width="20" height="40" fill="#A9733A" stroke="#7A5129" stroke-width="2"/>`;
  let ticks = "";
  for (let i = 0; i < 11; i++) ticks += `<path d="M724 ${352 + i * 10.6}h${i % 5 === 0 ? 11 : 6}" stroke="#8C846F" stroke-width="2"/>`;
  const win = (x, y, w, h) => `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4" fill="url(#hWin)"/><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="4" fill="none" stroke="#FAF9F5" stroke-width="8"/><path d="M${x + w / 2} ${y}v${h}M${x} ${y + h / 2}h${w}" stroke="#FAF9F5" stroke-width="5"/><rect x="${x - 8}" y="${y + h + 4}" width="${w + 16}" height="9" rx="3" fill="#D9CDB5"/></g>`;
  return SVG_OPEN("0 0 1200 900") + `
<defs>
  <linearGradient id="hSky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F8EBCF"/><stop offset="1" stop-color="#EBD3A6"/></linearGradient>
  <radialGradient id="hSun" cx=".82" cy=".13" r=".5"><stop offset="0" stop-color="#FFF6DB" stop-opacity=".95"/><stop offset="1" stop-color="#FFF6DB" stop-opacity="0"/></radialGradient>
  <linearGradient id="hGrass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8FB07A"/><stop offset="1" stop-color="#6F9565"/></linearGradient>
  <linearGradient id="hWin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFEBB0"/><stop offset="1" stop-color="#F6C46A"/></linearGradient>
  <linearGradient id="hLoft" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2A1B12"/><stop offset="1" stop-color="#60402A"/></linearGradient>
  <linearGradient id="hWool" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F8DA5E"/><stop offset="1" stop-color="#E9B83A"/></linearGradient>
  <radialGradient id="hLamp" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFE9A8" stop-opacity=".55"/><stop offset="1" stop-color="#FFE9A8" stop-opacity="0"/></radialGradient>
  <pattern id="hBrick" width="60" height="30" patternUnits="userSpaceOnUse"><rect width="60" height="30" fill="#B35B3D"/><path d="M0 0H60M0 15H60M0 30H60M0 0V15M30 0V15M15 15V30M45 15V30" stroke="#DDBBA3" stroke-width="2" opacity=".6"/></pattern>
  <pattern id="hSlate" width="48" height="28" patternUnits="userSpaceOnUse"><rect width="48" height="28" fill="#3A4A52"/><path d="M0 14H48M0 28H48M24 0V14M0 14V28M48 14V28" stroke="#28363D" stroke-width="2"/></pattern>
  <pattern id="hFibre" width="26" height="26" patternUnits="userSpaceOnUse"><path d="M2 7 10 3M13 16 22 11M4 22 12 18M17 5 24 2" stroke="#CF9E26" stroke-width="2" stroke-linecap="round" opacity=".55"/></pattern>
  <clipPath id="hLoftClip"><polygon points="181,470 600,182 1019,470"/></clipPath>
</defs>
<rect width="1200" height="900" fill="url(#hSky)"/><rect width="1200" height="900" fill="url(#hSun)"/>
<ellipse cx="170" cy="800" rx="260" ry="90" fill="#B7C99A"/><ellipse cx="1060" cy="810" rx="300" ry="100" fill="#A9BF8E"/>
<rect y="800" width="1200" height="100" fill="url(#hGrass)"/>
<ellipse cx="600" cy="808" rx="500" ry="18" fill="#3E5A3A" opacity=".25"/>
<g><rect x="92" y="640" width="14" height="170" fill="#6B4A32"/><circle cx="99" cy="610" r="70" fill="#6E9A6B"/><circle cx="70" cy="650" r="46" fill="#5E8A5C"/><circle cx="132" cy="648" r="44" fill="#78A474"/></g>
<rect x="160" y="470" width="880" height="330" fill="url(#hBrick)"/>
<rect x="160" y="628" width="880" height="12" fill="#D9CDB5"/>
<rect x="830" y="215" width="58" height="125" fill="url(#hBrick)"/><rect x="820" y="203" width="78" height="16" rx="3" fill="#8C5A44"/>
<polygon points="120,470 600,140 1080,470" fill="url(#hSlate)" stroke="#1F2A30" stroke-width="6" stroke-linejoin="round"/>
<polygon points="181,470 600,182 1019,470" fill="url(#hLoft)"/>
<g clip-path="url(#hLoftClip)">
  <circle cx="520" cy="300" r="190" fill="url(#hLamp)"/>
  <line x1="181" y1="470" x2="600" y2="182" stroke="#B9803F" stroke-width="18"/><line x1="1019" y1="470" x2="600" y2="182" stroke="#B9803F" stroke-width="18"/>
  <line x1="181" y1="470" x2="600" y2="182" stroke="#7C5128" stroke-width="2" transform="translate(0 -9)"/>
  <rect x="592" y="176" width="16" height="40" fill="#A9733A"/>
  <path d="M181 470 L338 366 Q380 352 430 362 T530 360 T640 366 T740 358 T862 366 L1019 470 Z" fill="url(#hWool)"/>
  <path d="M181 470 L338 366 Q380 352 430 362 T530 360 T640 366 T740 358 T862 366 L1019 470 Z" fill="url(#hFibre)"/>
  ${joists}
  <rect x="150" y="470" width="900" height="14" fill="#EFE8D8"/>
  <g transform="translate(540 258)">
    <path d="M10 82 L58 82 L76 104 L52 104 L40 94 L18 104 L2 104 Z" fill="#2F3B46"/>
    <rect x="14" y="30" width="44" height="56" rx="14" fill="#F2742B"/>
    <rect x="14" y="52" width="44" height="7" fill="#F4F1E8" opacity=".92"/><rect x="14" y="68" width="44" height="6" fill="#F4F1E8" opacity=".92"/>
    <circle cx="38" cy="18" r="14" fill="#E7B38C"/>
    <path d="M22 15 A16 16 0 0 1 54 15 Z" fill="#F4F1E8"/><rect x="19" y="13" width="38" height="5" rx="2.5" fill="#E6E1D2"/>
    <rect x="29" y="20" width="19" height="10" rx="5" fill="#D5DAD8" stroke="#A5ADAA" stroke-width="1.5"/>
    <path d="M52 40 L90 66" stroke="#F2742B" stroke-width="11" stroke-linecap="round"/><circle cx="94" cy="68" r="6.5" fill="#2F3B46"/>
  </g>
  <g><rect x="650" y="334" width="72" height="30" rx="15" fill="url(#hWool)" stroke="#CF9E26" stroke-width="2"/><ellipse cx="656" cy="349" rx="9" ry="14" fill="#F3D24E" stroke="#CF9E26" stroke-width="2"/><path d="M651 349a5 8 0 0 1 10 0" stroke="#CF9E26" stroke-width="2" fill="none"/></g>
  <rect x="724" y="352" width="14" height="118" rx="2" fill="#F4F1E8" stroke="#BDB59F" stroke-width="1.5"/>${ticks}
  <rect x="680" y="316" width="102" height="30" rx="9" fill="#0F2E24"/><text x="731" y="337" text-anchor="middle" ${FONT} font-size="19" font-weight="700" fill="#FAF9F5">270mm</text>
</g>
${win(236, 520, 130, 92)}${win(836, 520, 130, 92)}
<rect x="540" y="520" width="120" height="92" rx="4" fill="#F4EAD3"/><path d="M540 612h120M600 520v92" stroke="#D9CDB5" stroke-width="4"/>
${win(236, 676, 150, 100)}${win(814, 676, 150, 100)}
<rect x="548" y="668" width="104" height="132" rx="6" fill="#1B4A3A" stroke="#FAF9F5" stroke-width="6"/><rect x="566" y="690" width="68" height="44" rx="4" fill="#27614A"/><circle cx="632" cy="748" r="6" fill="#E2B64A"/>
<path d="M560 800 L520 900 H680 L640 800Z" fill="#D9CDB5"/>
<rect x="60" y="770" width="150" height="40" rx="20" fill="#5E8A5C"/><rect x="990" y="770" width="150" height="40" rx="20" fill="#5E8A5C"/>
</svg>`;
}

/* ---- before / after: identical 16:10 cross-section of the loft floor (shared composition) ---- */
function artLoft(after) {
  const p = after ? "a" : "b";
  let seed = after ? 11 : 5;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
  const base = 820, jTop = 690, jw = 62, joistX = [250, 770, 1290];
  const joists = joistX.map(cx => `<g><rect x="${cx - jw / 2}" y="${jTop}" width="${jw}" height="${base - jTop}" fill="#B07A43" stroke="#7A5129" stroke-width="3"/><path d="M${cx - 14} ${jTop + 12}v100M${cx + 6} ${jTop + 22}v80M${cx + 18} ${jTop + 10}v90" stroke="#8D5E31" stroke-width="2" opacity=".55"/></g>`).join("");
  // wavy top edge between x0 and x1 around height y
  const wavy = (x0, x1, y, amp) => { let d = `L${x0} ${y + (rnd() - .5) * amp}`; for (let x = x0 + 40; x < x1; x += 40) d += ` L${x} ${y + (rnd() - .5) * amp}`; return d + ` L${x1} ${y + (rnd() - .5) * amp}`; };
  let wool = "";
  if (!after) {
    // thin, patchy, yellowed wool between the joists, with two bare gaps
    const regions = [[0, 219, null], [281, 739, [560, 640]], [801, 1259, [930, 1010]], [1321, 1600, null]];
    regions.forEach(([x0, x1, gap]) => {
      const parts = gap ? [[x0, gap[0]], [gap[1], x1]] : [[x0, x1]];
      parts.forEach(([a, b]) => { wool += `<path d="M${a} ${base} ${wavy(a, b, 758, 26)} L${b} ${base}Z" fill="url(#bWool)"/><path d="M${a} ${base} ${wavy(a, b, 758, 26)} L${b} ${base}Z" fill="url(#bFibre)"/>`; });
    });
    wool += `<ellipse cx="420" cy="800" rx="90" ry="14" fill="#6B5A2A" opacity=".35"/><ellipse cx="1100" cy="802" rx="110" ry="12" fill="#6B5A2A" opacity=".3"/>`;
  } else {
    const top = `M0 ${base} ${wavy(0, 1600, 468, 16)} L1600 ${base}Z`;
    wool = `<path d="${top}" fill="url(#aWool)"/><path d="${top}" fill="url(#aFibre)"/><path d="${top}" fill="url(#aShade)"/>`;
  }
  const gx = after ? 1040 : 520;                    // ruler x
  const gTop = base - 351;                           // 270mm = 351px at 1.3px/mm
  const woolTop = after ? 468 : 758;
  let tk = "";
  for (let i = 0; i <= 27; i++) tk += `<path d="M${gx} ${base - i * 13}h${i % 5 === 0 ? 16 : 8}" stroke="#7D755F" stroke-width="2"/>`;
  const flagW = 132, flagX = after ? gx + 40 : gx + 40;
  const flag = `<path d="M${gx + 14} ${woolTop} H${flagX}" stroke="#FAF9F5" stroke-width="3" stroke-dasharray="6 5"/><rect x="${flagX}" y="${woolTop - 24}" width="${flagW}" height="48" rx="12" fill="#0F2E24"/><text x="${flagX + flagW / 2}" y="${woolTop + 8}" text-anchor="middle" ${FONT} font-size="26" font-weight="700" fill="#FAF9F5">${after ? "270mm" : "50mm"}</text>`;
  return SVG_OPEN("0 0 1600 1000") + `
<defs>
  <linearGradient id="${p}Bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1F150E"/><stop offset="1" stop-color="#4E3624"/></linearGradient>
  <radialGradient id="${p}Light" cx=".72" cy=".1" r=".7"><stop offset="0" stop-color="#FFE6A8" stop-opacity=".5"/><stop offset="1" stop-color="#FFE6A8" stop-opacity="0"/></radialGradient>
  <linearGradient id="${p}Ceil" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#E6DECB"/><stop offset="1" stop-color="#F3ECDC"/></linearGradient>
  <linearGradient id="${p}Wool" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${after ? "#F8DA5E" : "#CDAF58"}"/><stop offset="1" stop-color="${after ? "#EBBB3C" : "#A98A3D"}"/></linearGradient>
  <linearGradient id="aShade" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF3B8" stop-opacity=".35"/><stop offset=".25" stop-color="#FFF3B8" stop-opacity="0"/><stop offset="1" stop-color="#8A5E10" stop-opacity=".18"/></linearGradient>
  <pattern id="${p}Fibre" width="30" height="30" patternUnits="userSpaceOnUse"><path d="M3 8 12 3M15 19 26 13M5 26 14 21M20 6 28 3" stroke="${after ? "#CF9E26" : "#7A6428"}" stroke-width="2.5" stroke-linecap="round" opacity="${after ? ".5" : ".55"}"/></pattern>
</defs>
<rect width="1600" height="1000" fill="url(#${p}Bg)"/>
<path d="M0 460 L800 40 L1600 460 L1600 0 L0 0Z" fill="#150E09" opacity=".55"/>
<rect width="1600" height="1000" fill="url(#${p}Light)"/>
<path d="M0 470 L800 52" stroke="#B9803F" stroke-width="40"/><path d="M1600 470 L800 52" stroke="#B9803F" stroke-width="40"/>
<path d="M0 452 L800 32" stroke="#D3A062" stroke-width="5" opacity=".7"/><path d="M1600 452 L800 32" stroke="#D3A062" stroke-width="5" opacity=".7"/>
<rect x="780" y="30" width="40" height="70" fill="#A9733A"/>
<rect y="${base}" width="1600" height="180" fill="url(#${p}Ceil)"/>
<rect y="${base}" width="1600" height="6" fill="#B9AF98"/>
<rect y="${base + 6}" width="1600" height="174" fill="#FFF3D4" opacity=".25"/>
${after ? wool : joists + wool}
<rect x="${gx - 2}" y="${gTop}" width="26" height="351" rx="3" fill="#F4F1E8" stroke="#BDB59F" stroke-width="2"/>${tk}
${flag}
</svg>`;
}

/* ---- Pete portrait 4:5 (illustration placeholder) ---- */
function artPete() {
  return SVG_OPEN("0 0 800 1000") + `
<defs>
  <linearGradient id="pBg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#EEF3EF"/><stop offset="1" stop-color="#D3E2D9"/></linearGradient>
  <radialGradient id="pGlow" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#FFEFC6" stop-opacity=".95"/><stop offset="1" stop-color="#FFEFC6" stop-opacity="0"/></radialGradient>
</defs>
<rect width="800" height="1000" fill="url(#pBg)"/>
<circle cx="560" cy="280" r="260" fill="url(#pGlow)"/>
<g stroke="#B07A43" stroke-width="18" stroke-linecap="round"><path d="M80 0 L110 700"/><path d="M200 0 L226 700"/></g>
<g stroke="#8D5E31" stroke-width="12" stroke-linecap="round"><path d="M92 130H212M96 260H216M100 390H221M104 520H224M108 650H228"/></g>
<path d="M60 1000 C60 800 190 745 400 735 C610 745 740 800 740 1000Z" fill="#1B4A3A"/>
<path d="M345 630 V742 Q400 800 455 742 V630Z" fill="#D49A74"/><path d="M345 700 Q400 740 455 700 V742 Q400 800 345 742Z" fill="#C58F69"/>
<path d="M322 728 L400 868 L340 744Z" fill="#0F2E24"/><path d="M478 728 L400 868 L460 744Z" fill="#0F2E24"/>
<circle cx="565" cy="868" r="36" fill="#FAF9F5"/><path d="M547 876 L565 858 L583 876M551 886H579" stroke="#0F2E24" stroke-width="5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
<ellipse cx="272" cy="478" rx="26" ry="42" fill="#DCA17B"/><ellipse cx="528" cy="478" rx="26" ry="42" fill="#DCA17B"/>
<ellipse cx="400" cy="470" rx="130" ry="164" fill="#E6B18A"/>
<path d="M270 440 C258 296 330 258 400 258 C478 258 544 296 530 440 C522 384 490 340 400 336 C312 340 282 384 270 440Z" fill="#5E4B3E"/>
<path d="M270 440 C266 396 276 372 292 354 L300 400Z" fill="#A9A39B"/><path d="M530 440 C534 396 524 372 508 354 L500 400Z" fill="#A9A39B"/>
<path d="M334 424 Q364 408 394 422" stroke="#4A3B30" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M406 422 Q436 408 466 424" stroke="#4A3B30" stroke-width="10" fill="none" stroke-linecap="round"/>
<ellipse cx="364" cy="460" rx="21" ry="11" fill="#FFFFFF"/><ellipse cx="436" cy="460" rx="21" ry="11" fill="#FFFFFF"/>
<circle cx="366" cy="460" r="8.5" fill="#4B3425"/><circle cx="434" cy="460" r="8.5" fill="#4B3425"/><circle cx="368" cy="457" r="2.5" fill="#FFFFFF"/><circle cx="436" cy="457" r="2.5" fill="#FFFFFF"/>
<path d="M338 452 Q364 440 392 452M408 452 Q436 440 462 452" stroke="#B88661" stroke-width="3" fill="none" stroke-linecap="round"/>
<path d="M326 468l-14 -6M326 476l-15 2M474 468l14 -6M474 476l15 2" stroke="#C58F69" stroke-width="3" stroke-linecap="round"/>
<path d="M400 470 Q386 520 378 540 Q400 556 422 540 Q414 520 400 470" fill="#D9A07A" stroke="#C58F69" stroke-width="3" stroke-linejoin="round"/>
<path d="M286 528 Q300 640 400 668 Q500 640 514 528 Q480 596 400 606 Q320 596 286 528Z" fill="#7B6D61" opacity=".4"/>
<path d="M352 580 Q400 616 448 580" stroke="#8A4B3A" stroke-width="8" fill="none" stroke-linecap="round"/>
<path d="M360 584 Q400 612 440 584 Q400 596 360 584Z" fill="#FAF9F5"/>
<path d="M348 560 Q400 596 452 560" stroke="#7B6D61" stroke-width="3" fill="none" opacity=".35"/>
</svg>`;
}

/* ---- why-insulate heat-loss diagram (not an image slot; drawn inline) ---- */
function artWhy() {
  const arrow = (d, hx, hy, w, col, dir = "up") => {
    const head = { up: `${hx},${hy - 22} ${hx - 14},${hy + 4} ${hx + 14},${hy + 4}`, left: `${hx - 22},${hy} ${hx + 4},${hy - 12} ${hx + 4},${hy + 12}`, right: `${hx + 22},${hy} ${hx - 4},${hy - 12} ${hx - 4},${hy + 12}`, down: `${hx},${hy + 20} ${hx - 11},${hy - 4} ${hx + 11},${hy - 4}` }[dir];
    return `<path d="${d}" stroke="${col}" stroke-width="${w}" fill="none" stroke-linecap="round"/><polygon points="${head}" fill="${col}"/>`;
  };
  return `<svg viewBox="0 0 640 470" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Diagram of a house with large arrows leaving through the roof, labelled roughly a quarter, and smaller arrows leaving through the walls, windows and floor.">
<rect x="40" y="426" width="560" height="10" rx="5" fill="#1B4A3A" opacity=".18"/>
<rect x="408" y="150" width="34" height="80" fill="#B35B3D"/>
<rect x="150" y="248" width="340" height="178" fill="#FFFFFF" stroke="#0F2E24" stroke-width="5" stroke-linejoin="round"/>
<polygon points="118,248 320,118 522,248" fill="#1B4A3A" stroke="#0F2E24" stroke-width="5" stroke-linejoin="round"/>
<rect x="176" y="226" width="288" height="22" rx="3" fill="#F2C94C" stroke="#B88A12" stroke-width="2"/>
<rect x="186" y="292" width="72" height="62" rx="4" fill="#FFE3A3" stroke="#0F2E24" stroke-width="4"/><path d="M222 292v62M186 323h72" stroke="#0F2E24" stroke-width="3"/>
<rect x="382" y="292" width="72" height="62" rx="4" fill="#FFE3A3" stroke="#0F2E24" stroke-width="4"/><path d="M418 292v62M382 323h72" stroke="#0F2E24" stroke-width="3"/>
<rect x="288" y="338" width="64" height="88" rx="4" fill="#0F2E24"/><circle cx="338" cy="384" r="4" fill="#FAF9F5"/>
${arrow("M232 222 C222 176 244 138 232 92", 232, 82, 9, "#E2693A")}
${arrow("M292 222 C282 170 304 130 292 82", 292, 72, 9, "#E2693A")}
${arrow("M352 222 C342 170 364 130 352 82", 352, 72, 9, "#E2693A")}
${arrow("M412 222 C402 176 424 138 412 92", 412, 82, 9, "#E2693A")}
${arrow("M150 330 H92", 84, 330, 5, "#7A8B83", "left")}${arrow("M490 330 H548", 556, 330, 5, "#7A8B83", "right")}
${arrow("M150 392 H112", 104, 392, 4, "#7A8B83", "left")}${arrow("M490 392 H528", 536, 392, 4, "#7A8B83", "right")}
${arrow("M244 428 V456", 244, 452, 4, "#7A8B83", "down")}${arrow("M396 428 V456", 396, 452, 4, "#7A8B83", "down")}
<rect x="172" y="8" width="296" height="46" rx="23" fill="#0F2E24"/><text x="320" y="38" text-anchor="middle" ${FONT} font-size="24" font-weight="700" fill="#FAF9F5">Roughly a quarter</text>
<text x="320" y="216" text-anchor="middle" ${FONT} font-size="0" fill="none"> </text>
</svg>`;
}

/* ---- service area map 16:9 (illustrative, not to scale) ---- */
function artMap() {
  const cx = 800, cy = 450;
  const t = (name, dx, dy, label, anchor = "start") => `<g><circle cx="${cx + dx}" cy="${cy + dy}" r="${label ? 11 : 8}" fill="${name === "Nottingham" ? "#0F2E24" : "#1B4A3A"}"/>${label ? `<text x="${cx + dx + (anchor === "start" ? 22 : -22)}" y="${cy + dy + 12}" text-anchor="${anchor}" ${FONT} font-size="38" font-weight="700" fill="#0F2E24">${label}</text>` : ""}</g>`;
  return SVG_OPEN("0 0 1600 900") + `
<defs><pattern id="mDots" width="40" height="40" patternUnits="userSpaceOnUse"><circle cx="4" cy="4" r="2" fill="#0F2E24" opacity=".08"/></pattern></defs>
<rect width="1600" height="900" fill="#E8F0EC"/><rect width="1600" height="900" fill="url(#mDots)"/>
<path d="M520 40 L980 70 L1130 260 L1060 520 L880 560 L700 520 L560 400 L500 220Z" fill="#D5E3DB"/>
<path d="M200 300 L520 220 L560 400 L700 520 L680 700 L430 800 L240 660Z" fill="#CBDDD2"/>
<path d="M700 520 L880 560 L1060 520 L1230 640 L1180 830 L900 870 L680 700Z" fill="#DCE9E1"/>
<g fill="none" stroke="#FAF9F5" stroke-width="5" stroke-linejoin="round"><path d="M520 220 L560 400 L700 520 L880 560 L1060 520"/><path d="M700 520 L680 700"/></g>
<text x="780" y="140" text-anchor="middle" ${FONT} font-size="30" font-weight="600" fill="#4B5563" letter-spacing="4">NOTTINGHAMSHIRE</text>
<text x="330" y="500" text-anchor="middle" ${FONT} font-size="30" font-weight="600" fill="#4B5563" letter-spacing="4">DERBYSHIRE</text>
<text x="1000" y="800" text-anchor="middle" ${FONT} font-size="30" font-weight="600" fill="#4B5563" letter-spacing="4">LEICESTERSHIRE</text>
<circle cx="${cx}" cy="${cy}" r="340" fill="#1B4A3A" opacity=".06"/>
<circle cx="${cx}" cy="${cy}" r="340" fill="none" stroke="#0F2E24" stroke-width="3" stroke-dasharray="14 12" opacity=".5"/>
<rect x="${cx + 120}" y="${cy + 196}" width="270" height="50" rx="25" fill="#0F2E24"/><text x="${cx + 255}" y="${cy + 230}" text-anchor="middle" ${FONT} font-size="26" font-weight="600" fill="#FAF9F5">about 25 miles</text>
${t("Beeston", -52, 40)}${t("West Bridgford", 8, 62)}${t("Arnold", 58, -52)}${t("Sherwood", 10, -48)}${t("Carlton", 125, 34)}${t("Hucknall", -36, -150)}${t("Long Eaton", -128, 70)}${t("Ilkeston", -160, -30)}${t("Belper", -230, -100)}${t("Loughborough", -60, 205)}${t("Melton", 190, 175)}
${t("Derby", -205, 108, "Derby", "end")}${t("Leicester", -40, 292, "Leicester", "end")}${t("Mansfield", -88, -196, "Mansfield", "end")}${t("Newark", 240, -165, "Newark", "start")}
${t("Nottingham", 0, 0, "Nottingham", "start")}
<circle cx="${cx}" cy="${cy}" r="22" fill="none" stroke="#0F2E24" stroke-width="4"/>
</svg>`;
}

/* ---- image manifest: components reference images by id, never by path ---- */
const IMAGES = {
  hero: { id: "hero", src: null, alt: "Cutaway of a semi-detached house showing a loft laid with 270mm of mineral wool, an installer in hi-vis and a depth gauge reading 270mm.", width: 1200, height: 900, aspectRatio: "4/3", aspectRatioMobile: "4/5", sizes: "(min-width:960px) 48vw, 100vw", priority: true, objectPosition: "50% 50%", blurDataURL: null, isPlaceholder: true, credit: "Original SVG illustration. PLACEHOLDER - replace for real client", art: artHero },
  before: { id: "before", src: "data:image/jpeg;base64,__BEFORE_IMG__", alt: "Before: a thin, patchy, grey-yellow layer of old wool with timber joists poking through and bare gaps.", width: 1200, height: 896, aspectRatio: "3/2", sizes: "(min-width:1000px) 56vw, 100vw", priority: false, objectPosition: "50% 50%", blurDataURL: null, isPlaceholder: true, credit: "Original SVG illustration. PLACEHOLDER - replace for real client", art: () => artLoft(false) },
  after: { id: "after", src: "data:image/jpeg;base64,__AFTER_IMG__", alt: "After: a deep, even layer of fresh yellow mineral wool covering the joists.", width: 1200, height: 896, aspectRatio: "3/2", sizes: "(min-width:1000px) 56vw, 100vw", priority: false, objectPosition: "50% 50%", blurDataURL: null, isPlaceholder: true, credit: "Original SVG illustration. PLACEHOLDER - replace for real client", art: () => artLoft(true) },
  pete: { id: "pete", src: "data:image/jpeg;base64,__PETE_IMG__", alt: "Pete Ashworth, smiling, in a loft holding a roll of insulation.", width: 800, height: 889, aspectRatio: "4/5", sizes: "(min-width:900px) 420px, 90vw", priority: false, objectPosition: "50% 28%", blurDataURL: null, isPlaceholder: true, credit: "Supplied by client (demo placeholder image)", art: artPete },
  area: { id: "area", src: null, alt: "Simple map showing Nottingham at the centre with a dashed ring about 25 miles wide covering parts of Nottinghamshire, Derbyshire and Leicestershire. Illustrative, not to scale.", width: 1600, height: 900, aspectRatio: "16/9", sizes: "(min-width:960px) 56vw, 100vw", priority: false, objectPosition: "50% 50%", blurDataURL: null, isPlaceholder: true, credit: "Original SVG illustration. PLACEHOLDER - replace for real client", art: artMap }
};
