/* =====================================================================
   App: renders every section from SITE (config.js) and wires the interactions.
   No network calls, no storage, no analytics. Motion is CSS-first; JS only
   toggles classes (one shared IntersectionObserver + one pointer handler).
   ===================================================================== */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = s => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const reduced = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const money = n => "£" + n.toLocaleString("en-GB");

  let C;
  try { C = validateConfig(SITE); } catch (e) {
    document.body.innerHTML = `<pre style="padding:24px;white-space:pre-wrap;color:#B42318">${esc(e.message)}</pre>`; throw e;
  }
  const B = C.business, K = C.contact;

  /* ---------- theme tokens from config ---------- */
  (function applyTheme() {
    const m = { evergreen: "--evergreen", evergreen800: "--evergreen-800", evergreen50: "--evergreen-50", evergreenDeep: "--evergreen-deep", amber: "--amber", amberHover: "--amber-hover", amberSoft: "--amber-soft", cream: "--cream", charcoal: "--charcoal", muted: "--muted", heat: "--heat" };
    Object.entries(m).forEach(([k, v]) => C.colours[k] && document.documentElement.style.setProperty(v, C.colours[k]));
  })();

  /* ---------- icons ---------- */
  const P = {
    check: '<path d="M20 6 9 17l-5-5"/>', x: '<path d="M18 6 6 18M6 6l12 12"/>',
    chevR: '<path d="m9 18 6-6-6-6"/>', chevL: '<path d="m15 18-6-6 6-6"/>', chevD: '<path d="m6 9 6 6 6-6"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    shield: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    badge: '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z" stroke-dasharray="3 3"/>',
    award: '<circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/>',
    pound: '<path d="M18 7c0-5.333-8-5.333-8 0"/><path d="M10 7v14"/><path d="M6 21h12"/><path d="M6 13h10"/>',
    thermo: '<path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z"/>',
    drops: '<path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"/><path d="M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97"/>',
    drop: '<path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>',
    layers: '<path d="M12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>',
    grid: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18M3 15h18M9 3v18M15 3v18"/>',
    box: '<path d="M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z"/><path d="M12 22V12"/><path d="m3.3 7 8.7 5 8.7-5"/>',
    wind: '<path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/><path d="M9.6 4.6A2 2 0 1 1 11 8H2"/><path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>',
    tank: '<rect x="4" y="3" width="10" height="13" rx="2.5"/><path d="M14 8h3a3 3 0 0 1 3 3v10"/><path d="M9 16v5"/>',
    ruler: '<path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2"/><path d="m11.5 9.5 2-2"/><path d="m8.5 6.5 2-2"/><path d="m17.5 15.5 2-2"/>',
    home: '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
    smile: '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><path d="M9 9h.01M15 9h.01"/>',
    pin: '<path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"/><circle cx="12" cy="10" r="3"/>',
    info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
    camera: '<path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/>',
    alert: '<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>',
    star: '<path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="currentColor"/>'
  };
  const icon = (n, s = 24, extra = "") => `<svg viewBox="0 0 24 24" width="${s}" height="${s}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" ${extra}>${P[n]}</svg>`;
  const stars = (n = 5, s = 20) => `<span class="stars" aria-hidden="true">${Array(n).fill(icon("star", s)).join("")}</span>`;
  const HOUSE = {
    terrace: '<path d="M2 28V14l7-6 7 6 7-6 7 6 7-6 7 6v14z"/><path d="M6 28v-7h6v7M20 28v-7h6v7M34 28v-7h6v7"/>',
    semi: '<path d="M3 28V15L13.5 6 24 15 34.5 6 45 15v13z"/><path d="M24 15v13M9 28v-8h7v8M32 28v-8h7v8"/>',
    detached: '<path d="M7 28V15L21 5l14 10v13z"/><path d="M18 28v-9h6v9M35 28h7V19h-7"/>',
    bungalow: '<path d="M3 28V18L24 8l21 10v10z"/><path d="M21 28v-8h6v8M8 28v-5h7v5M33 28v-5h7v5"/>'
  };
  const houseIcon = id => `<svg viewBox="0 0 48 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${HOUSE[id]}</svg>`;
  const logoMark = (dark) => `<svg viewBox="0 0 40 40" aria-hidden="true" focusable="false"><rect width="40" height="40" rx="11" fill="${dark ? "#FAF9F5" : "#0F2E24"}"/><path d="M8 20 20 9l12 11" stroke="${dark ? "#0F2E24" : "#FAF9F5"}" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 25h16M12 30h16" stroke="${dark ? "#0F2E24" : "#FAF9F5"}" stroke-width="3" stroke-linecap="round" opacity=".8"/></svg>`;

  /* ---------- media (by id only) ---------- */
  const artInner = id => { const m = IMAGES[id]; return m.src ? `<img src="${m.src}" alt="" width="${m.width}" height="${m.height}" sizes="${m.sizes}" loading="lazy" decoding="async" style="object-position:${m.objectPosition}">` : m.art(); };
  function media(id, cls = "") {
    const m = IMAGES[id];
    const style = `--ar:${m.aspectRatio};${m.aspectRatioMobile ? `--ar-m:${m.aspectRatioMobile};` : ""}`;
    const inner = m.src
      ? `<img src="${m.src}" alt="${esc(m.alt)}" width="${m.width}" height="${m.height}" sizes="${m.sizes}" ${m.priority ? 'fetchpriority="high"' : 'loading="lazy" decoding="async"'} style="object-position:${m.objectPosition}">`
      : m.art();
    const a11y = m.src ? "" : (m.alt === "" ? 'aria-hidden="true"' : `role="img" aria-label="${esc(m.alt)}"`);
    return `<figure class="media ${cls}" style="${style}" ${a11y}>${inner}</figure>`;
  }

  /* ---------- building blocks ---------- */
  const cta = (o = {}) => `<button type="button" class="btn btn-cta${o.lg ? " btn-lg" : ""}" data-open-quote${o.pkg ? ` data-pkg="${o.pkg}"` : ""}${o.prop ? ` data-prop="${o.prop}"` : ""} aria-haspopup="dialog">${esc(C.ctaLabel)}</button>`;
  const ctaBlock = (lg) => `<div class="cta-block">${cta({ lg })}<p class="micro">${esc(C.ctaMicro)}</p></div>`;
  const head = (eyebrow, title, lead, center) => `<div class="sec-head${center ? " center" : ""}"><p class="eyebrow">${esc(eyebrow)}</p><h2>${esc(title)}</h2>${lead ? `<p class="lead">${esc(lead)}</p>` : ""}</div>`;
  const ambient = (variant, shapes) => `<div class="ambient v-${variant}" aria-hidden="true">${shapes.filter(s => s.kind !== "ring").map(s => `<i class="shp ${s.kind} t-${s.tone}" style="--x:${s.x}%;--y:${s.y}%;--s:${s.size}px;--op:${s.op};--dur:${s.dur}s;--dl:${s.delay}s;--dx:${s.dx}px;--dy:${s.dy}px;--rot:${s.rot}deg;--sc:${s.sc}"></i>`).join("")}</div>`;

  /* dividers */
  const BG = { cream: "#FAF9F5", e50: "#E8F0EC", dark: "#0F2E24", deep: "#0A2119" };
  const col = k => ({ cream: C.colours.cream, e50: C.colours.evergreen50, dark: C.colours.evergreen, deep: C.colours.evergreenDeep }[k] || BG[k]);
  function wavePath(m, a, n) {
    const w = 2400 / n, L = w / 2; let d = `M0 ${m}`;
    for (let i = 0; i < n; i++) {
      const x = i * w;
      d += ` C${x + L * .36} ${m - a * 1.28} ${x + L * .64} ${m - a * 1.28} ${x + L} ${m}`;
      d += ` C${x + L + L * .36} ${m + a * 1.28} ${x + L + L * .64} ${m + a * 1.28} ${x + w} ${m}`;
    }
    return d + " L2400 100 L0 100Z";
  }
  const WAVES = [wavePath(46, 14, 2), wavePath(52, 24, 4), wavePath(50, 30, 2)];
  let wi = 0;
  function wave(from, to, flip) {
    const i = wi++, f = WAVES[i % 3], b = WAVES[(i + 1) % 3];
    return `<div class="divider wave${flip ? " flip" : ""}" style="--from:${col(from)};--to:${col(to)};--t1:${32 + (i % 4) * 4}s;--t2:${44 + (i % 3) * 5}s" aria-hidden="true"><div class="wv"><svg class="back" viewBox="0 0 2400 100" preserveAspectRatio="none"><path d="${b}"/></svg><svg class="front" viewBox="0 0 2400 100" preserveAspectRatio="none"><path d="${f}"/></svg></div></div>`;
  }
  const line = (from, to, dark) => `<div class="divider line" style="--from:${col(from)};--to:${col(to)};--lc:${dark ? "rgba(250,249,245,.2)" : "rgba(15,46,36,.2)"}" aria-hidden="true"><div class="lb"><span class="ln"></span><span class="dot"></span></div></div>`;

  /* ---------- sections ---------- */
  function header() {
    const links = C.nav.map(n => `<a href="${n.href}">${esc(n.label)}</a>`).join("");
    return `<header class="hdr"><div class="in">
      <a class="logo" href="#top" aria-label="${esc(B.name)}, back to top">${logoMark()}<span class="nm"><b>${esc(B.short)}</b><small>Loft Insulation</small></span></a>
      <nav class="nav" aria-label="Main">${links}<a class="phone" href="tel:${K.phoneHref}">${esc(K.phone)}</a></nav>
      <div class="hdr-r"><a class="hcall" href="tel:${K.phoneHref}" aria-label="Call ${esc(K.phone)}">${icon("phone", 22)}</a><button class="burger" id="burger" type="button" aria-expanded="false" aria-controls="menu" aria-label="Open menu">${icon("menu", 24)}</button></div>
      <div class="menu" id="menu" hidden>${links}<a class="phone" href="tel:${K.phoneHref}">Call ${esc(K.phone)}</a></div>
    </div></header>`;
  }

  function hero() {
    const H = C.hero;
    return `<section class="sec dark hero" id="top" aria-labelledby="h1"><div class="hero-bg" aria-hidden="true"></div>
      <div class="wrap hero-grid"><div class="hero-copy">
        <h1 id="h1">${esc(H.headline)}</h1>
        <ul class="ticks">${H.bullets.map(b => `<li><span class="ck">${icon("check", 16, 'stroke-width="3"')}</span>${esc(b)}</li>`).join("")}</ul>
        <div class="hero-cta">${cta({ lg: true })}<p class="micro">${esc(C.ctaMicro)}</p></div>
        <div class="proof"><span>${stars(5, 18)}<b>${B.rating}</b> from ${B.reviewCount} reviews</span><span>${icon("pin", 18)}${esc(H.team)}</span></div>
      </div>
      </div></section>`;
  }

  function trust() {
    return `<section class="sec cream trust" aria-label="Why people trust us"><div class="wrap"><div class="trust-grid">${C.trust.map(t =>
      `<div class="tr"><span class="ic${t.icon === "badge" ? " dash" : ""}">${t.icon === "star" ? icon("star", 24) : icon(t.icon, 24)}</span><div><b>${esc(t.title)}</b><span>${esc(t.text)}</span></div></div>`).join("")}</div></div></section>`;
  }

  function why() {
    const W = C.why;
    return `<section class="sec cream" id="why" aria-labelledby="whyH">${ambient("light", C.shapes.why)}<div class="wrap">
      <div class="why-grid"><div>
        <p class="eyebrow">Why insulate</p><h2 id="whyH" style="margin-top:14px">${esc(W.headline)}</h2>
        <p class="lead" style="margin-top:16px">${esc(W.body)}</p>
        <div class="bigstat"><b>${esc(W.stat)}</b><span>${esc(W.statNote)}</span></div>
        <p class="fine">${esc(W.fine)}</p>
      </div><figure class="dia" style="margin:0"><img class="dia-img" src="data:image/jpeg;base64,__WHY_IMG__" alt="A brick semi-detached house at dusk with the roof glowing orange and arrows showing heat escaping upwards and sideways." width="1200" height="896" loading="lazy" decoding="async"><figcaption>${esc(W.caption)}</figcaption></figure></div>
      <div class="benefits">${W.benefits.map(b => `<div class="card benefit"><span class="ic">${icon(b.icon, 26)}</span><h3>${esc(b.title)}</h3><p>${esc(b.text)}</p></div>`).join("")}</div></div></section>`;
  }

  function services() {
    return `<section class="sec e50" id="what-we-do" aria-labelledby="svcH"><div class="wrap">
      <div class="sec-head"><p class="eyebrow">What we do</p><h2 id="svcH">Everything your loft needs, from one tidy crew.</h2></div>
      <div class="svc-grid">${C.services.map(s => `<article class="card svc"><span class="ic">${icon(s.icon, 28)}</span><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p></article>`).join("")}</div></div></section>`;
  }

  function every() {
    return `<section class="sec cream" id="how-it-works" aria-labelledby="howH"><div class="wrap">
      <div class="sec-head"><p class="eyebrow">How it works</p><h2 id="howH">Three steps. Most jobs are done in a day.</h2></div>
      <div class="steps">${C.steps.map((s, i) => `<div class="step"><span class="n" aria-hidden="true">${i + 1}</span><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p></div>`).join("")}</div>
      <div class="incl"><div><p class="eyebrow">Included as standard</p><h2 style="margin-top:14px;font-size:clamp(1.75rem,1.2rem + 2vw,2.5rem)">Every job includes</h2><p class="lead" style="margin-top:14px">The same standard on every loft, big or small.</p></div>
      <ul class="check-list">${C.included.map(i => `<li><span class="ck">${icon("check", 15, 'stroke-width="3"')}</span><span>${esc(i)}</span></li>`).join("")}</ul></div>
    </div></section>`;
  }

  function pricing() {
    const def = C.defaultHouse, houseFull = id => C.houseTypes.find(h => h.id === id).full;
    const seg = C.houseTypes.map(h => `<label><input type="radio" name="house" value="${h.id}" ${h.id === def ? "checked" : ""}><span class="opt">${houseIcon(h.id)}${esc(h.label)}</span></label>`).join("");
    const cards = C.packages.map((p, i) => `<article class="card pk${p.featured ? " feat" : ""}" aria-labelledby="pk-${p.id}">
      ${p.badge ? `<span class="badge">${icon("star", 14)}${esc(p.badge)}</span>` : ""}
      <div><h3 id="pk-${p.id}">${esc(p.name)}</h3></div><p class="tag">${esc(p.tag)}</p>
      <div class="pr"><small>from</small><span class="price" data-price="${i}">${money(C.prices[def][i])}</span></div>
      <p class="for" data-for>${esc(houseFull(def))}. Fixed price confirmed after your free check.</p>
      <ul>${p.features.map(f => `<li><span class="ck">${icon("check", 13, 'stroke-width="3"')}</span><span>${esc(f)}</span></li>`).join("")}</ul></article>`).join("");
    return `<section class="sec cream" id="pricing" aria-labelledby="prH"><div class="wrap">
      <div class="sec-head center"><p class="eyebrow">Pricing guide</p><h2 id="prH">Fixed prices, no guesswork.</h2><p class="lead">Pick your house type to see what a typical job costs. Your exact price comes in writing after your free loft check.</p></div>
      <fieldset class="seg" id="seg"><legend class="sr">House type</legend>${seg}</fieldset>
      <p class="sr" id="priceLive" aria-live="polite"></p>
      <div class="pk-grid">${cards}</div>
    </div></section>`;
  }

  function promises() {
    const G = C.guarantees;
    return `<section class="sec dark" id="promises" aria-labelledby="pmH"><div class="wrap">
      <div class="sec-head center"><p class="eyebrow">Our guarantee</p><h2 id="pmH">${esc(G.title)}</h2></div>
      <div class="pr-grid">${G.items.map(g => `<article class="pm"><span class="ic">${icon(g.icon, 20)}</span><h3>${esc(g.title)}</h3><p>${esc(g.text)}</p></article>`).join("")}</div>
      <p class="smallprint">${esc(G.smallPrint)}</p></div></section>`;
  }

  function results() {
    const R = C.caseStudy;
    const st = R.stats.map(s => `<div class="stat"><small>${esc(s.label)}</small><b>${esc(s.value)}</b></div>`).join("");
    return `<section class="sec cream" id="results" aria-labelledby="resH"><div class="wrap">
      <div class="sec-head"><p class="eyebrow">Results: before &amp; after</p><h2 id="resH">${esc(R.title)}</h2></div>
      <div class="res-grid"><div>
        <div class="cmp" id="cmp"><div class="layer before">${artInner("before")}</div><div class="layer after">${artInner("after")}</div>
          <input type="range" id="cmpRange" min="0" max="100" step="1" value="50" aria-label="Compare before and after. Use the left and right arrow keys to move the divider." aria-valuetext="Divider at 50%. Before on the left, after on the right.">
          <div class="handle"><span class="knob">${icon("chevL", 18, 'stroke-width="3"')}${icon("chevR", 18, 'stroke-width="3"')}</span></div>
          <span class="lab b">Before</span><span class="lab a">After</span></div>
      </div>
      <div class="stats">${st}
        <div class="stat saving"><span class="ic">${icon("thermo", 26)}</span><div><small>Estimated saving</small><b>${esc(R.saving.value)}</b><p>${esc(R.saving.note)}</p></div></div>
      </div></div></div></section>`;
  }

  function reviews() {
    const R = C.reviews, n = R.items.length;
    return `<section class="sec e50" id="reviews" aria-label="Customer reviews"><div class="wrap">
      <p class="eyebrow rv-label">Reviews</p>
      <div class="rv" id="rv" role="region" aria-roledescription="carousel" aria-label="Customer reviews">
        <div class="rv-track" id="rvTrack" tabindex="0" aria-label="Reviews. Use the left and right arrow keys to move between them.">
          ${R.items.map((r, i) => `<figure class="rv-card" role="group" aria-roledescription="slide" aria-label="${i + 1} of ${n}">${stars(5, 20)}<blockquote>&ldquo;${esc(r.text)}&rdquo;</blockquote><footer><b>${esc(r.name)}</b><span>${esc(r.town)} &middot; ${esc(r.type)}</span></footer></figure>`).join("")}
        </div>
        <div class="rv-ctl"><button type="button" class="arrow" id="rvPrev" aria-label="Previous review" disabled>${icon("chevL", 22, 'stroke-width="2.5"')}</button><div class="rv-dots" id="rvDots"></div><button type="button" class="arrow" id="rvNext" aria-label="Next review">${icon("chevR", 22, 'stroke-width="2.5"')}</button></div>
      </div></div></section>`;
  }

  function faq() {
    return `<section class="sec cream" id="faq" aria-labelledby="faqH"><div class="wrap">
      <div class="sec-head center"><p class="eyebrow">FAQ</p><h2 id="faqH">Questions people ask us</h2></div>
      <div class="acc">${C.faqs.map((f, i) => `<div class="acc-item"><h3><button type="button" class="acc-btn" id="q${i}" aria-expanded="${i === 0}" aria-controls="a${i}"><span>${esc(f.q)}</span>${icon("chevD", 22, 'stroke-width="2.5"')}</button></h3>
        <div class="acc-panel${i === 0 ? " open" : ""}" id="a${i}" role="region" aria-labelledby="q${i}" ${i === 0 ? "" : "inert"}><div><p>${esc(f.a)}</p></div></div></div>`).join("")}</div>
      <p class="faq-after">${esc(C.faqAfter)}</p>
    </div></section>`;
  }

  function about() {
    const A = C.about;
    return `<section class="sec e50 about" id="about" aria-labelledby="abH">${ambient("light", C.shapes.about)}<div class="wrap about-grid">
      ${media("pete")}
      <div class="body"><p class="eyebrow">About Pete</p><h2 id="abH">${esc(A.headline)}</h2>${A.paras.map(p => `<p class="lead" style="color:var(--charcoal)">${esc(p)}</p>`).join("")}
        <p class="sig">&ldquo;${esc(C.owner.line)}&rdquo;<small>Pete Ashworth, founder</small></p></div></div></section>`;
  }

  function area() {
    const A = C.area;
    return `<section class="sec cream area" id="area" aria-labelledby="arH"><div class="wrap">
      <div class="sec-head center"><p class="eyebrow">Service area</p><h2 id="arH">${esc(A.headline)}</h2><p class="lead">${esc(A.text)}</p></div>
      <ul class="towns" aria-label="Towns we cover">${A.towns.map(t => `<li>${icon("pin", 16)}<span>${esc(t)}</span></li>`).join("")}</ul></div></section>`;
  }

  function finalBand() {
    const F = C.final;
    return `<section class="sec dark final" aria-labelledby="fnH"><div class="wrap"><h2 id="fnH">${esc(F.headline)}</h2><p class="lead">${esc(F.sub)}</p>${ctaBlock(true)}</div></section>`;
  }

  function footer() {
    const O = C.owner;
    return `<footer class="sec deep foot"><div class="wrap">
      <div class="foot-grid">
        <div><a class="logo" href="#top" aria-label="${esc(B.name)}, back to top">${logoMark(true)}<span class="nm"><b>${esc(B.short)}</b><small>Loft Insulation</small></span></a><p style="margin-top:18px;max-width:34ch">${esc(B.blurb)}</p></div>
        <div><h4>Services</h4><ul>${C.services.map(s => `<li><a href="#what-we-do">${esc(s.title)}</a></li>`).join("")}</ul></div>
        <div><h4>Contact</h4><address><a href="tel:${K.phoneHref}">${esc(K.phone)}</a><br>${esc(K.email)}<br><span style="display:block;margin-top:10px">${K.address.map(esc).join("<br>")}</span></address>
          <div class="hours">${K.hours.map(h => `<span>${esc(h[0])}</span><span>${esc(h[1])}</span>`).join("")}</div></div>
      </div>
      <p class="disc-line">${esc(C.disclaimers.footer)}</p>
      <div class="foot-bot"><span>&copy; ${new Date().getFullYear()} ${esc(B.name)} (fictional)</span><ul><li><a href="#" data-placeholder>Privacy</a></li><li><a href="#" data-placeholder>Terms</a></li><li><a href="#" data-placeholder>Cookies</a></li></ul></div>
    </div></footer>`;
  }

  /* ---------- quote popup markup (5 pages; choices advance on one tap) ---------- */
  const PROP_OPTS = [["detached", "Detached"], ["semi", "Semi-detached"], ["terrace", "Terrace"], ["bungalow", "Bungalow"]];
  const INS_OPTS = [["none", "None", "Bare joists, nothing up there"], ["some", "Some", "There's a layer already"], ["unsure", "Not sure", "Pete will measure it for free"]];
  const WORK_OPTS = [["essential", "Essential Top-up", "Wool to 270mm, hatch, tank and pipes"], ["warm-store", "Warm & Store", "Plus raised boarding for storage"], ["full-loft", "Full Loft Service", "Plus clearance, refit and extra vents"], ["unsure", "Not sure", "Pete will recommend after the check"]];
  const TITLES = ["What type of property is it?", "Is there insulation in the loft now?", "What work would you like?", "What's your postcode?", "Who should Pete ring?"];
  const TOTAL = TITLES.length;
  const errLine = id => `<p class="err" id="e-${id}">${icon("alert", 16)}<span></span></p>`;
  const rowOpts = (name, opts) => `<div class="rows">${opts.map(([v, l, d]) => `<label class="tile row-o"><input type="radio" name="${name}" value="${v}" aria-describedby="e-${name}"><span class="tb"><span><b>${esc(l)}</b><small>${esc(d)}</small></span></span></label>`).join("")}</div>`;
  function dialogHtml() {
    return `<dialog id="quote" aria-labelledby="qTitle"><div class="qd">
      <div class="qd-head"><div><p class="st" id="qStep">Step 1 of ${TOTAL}</p><h2 id="qTitle" tabindex="-1">${TITLES[0]}</h2></div><button type="button" class="qd-x" id="qClose" aria-label="Close quote form">${icon("x", 22)}</button></div>
      <div class="prog" id="qProg" role="progressbar" aria-label="Quote progress" aria-valuemin="1" aria-valuemax="${TOTAL}" aria-valuenow="1"><span></span></div>
      <p class="qd-demo">${icon("info", 18)}<span>${esc(C.disclaimers.form)}</span></p>
      <form id="qform" novalidate>
        <div class="qd-body" id="qBody">
          <div class="banner" id="qBanner" role="alert" tabindex="-1" hidden></div>
          <div class="pg" data-step="1">
            <fieldset class="field" data-field="property"><legend class="sr">${TITLES[0]}</legend>
              <div class="tiles big">${PROP_OPTS.map(([v, l]) => `<label class="tile"><input type="radio" name="property" value="${v}" aria-describedby="e-property"><span class="tb">${houseIcon(v)}${l}</span></label>`).join("")}</div>
              <p class="hint">Tap an option and we'll move straight on.</p>${errLine("property")}</fieldset></div>
          <div class="pg" data-step="2" hidden>
            <fieldset class="field" data-field="insulation"><legend class="sr">${TITLES[1]}</legend>${rowOpts("insulation", INS_OPTS)}
              <p class="hint">Tap an option and we'll move straight on.</p>${errLine("insulation")}</fieldset></div>
          <div class="pg" data-step="3" hidden>
            <fieldset class="field" data-field="work"><legend class="sr">${TITLES[2]}</legend>${rowOpts("work", WORK_OPTS)}
              <p class="hint">Tap an option and we'll move straight on.</p>${errLine("work")}</fieldset></div>
          <div class="pg" data-step="4" hidden>
            <div class="field" data-field="postcode"><label for="qPostcode">Your postcode</label>
              <input class="input" id="qPostcode" name="postcode" type="text" autocomplete="postal-code" placeholder="e.g. NG2 0AB" maxlength="9" aria-describedby="h-postcode e-postcode" style="text-transform:uppercase">
              <p class="hint" id="h-postcode">So Pete's team can check your area.</p>${errLine("postcode")}</div></div>
          <div class="pg" data-step="5" hidden>
            <div class="field" data-field="name"><label for="qName">Your name</label><input class="input" id="qName" name="name" type="text" autocomplete="name" aria-describedby="e-name" maxlength="80">${errLine("name")}</div>
            <div class="field" data-field="phone"><label for="qPhone">Phone number</label><input class="input" id="qPhone" name="phone" type="tel" inputmode="tel" autocomplete="tel" placeholder="e.g. 07700 900123" aria-describedby="h-phone e-phone" maxlength="20"><p class="hint" id="h-phone">UK numbers only. Pete rings you, no sales calls.</p>${errLine("phone")}</div>
            <div class="field"><label for="qPhoto">Loft photo (optional)</label>
              <label class="drop" for="qPhoto"><span id="qPhotoPrev">${icon("camera", 28)}</span><span><span id="qPhotoName">Add a photo of your loft</span><small>Stays on your device. Nothing is uploaded.</small></span><input type="file" id="qPhoto" accept="image/*"></label></div>
          </div>
        </div>
        <div class="qd-actions"><button type="button" class="btn btn-out" id="qBack" hidden>Back</button><button type="submit" class="btn btn-ev" id="qNext">Continue</button></div>
      </form>
      <div class="ok" id="qOk" hidden>
        <span class="tick">${icon("check", 32, 'stroke-width="3"')}</span><h3 id="qThanks" tabindex="-1"></h3>
        <p>That's the end of the demo, so nobody will actually ring. On a live site this is where your enquiry would land.</p>
        <dl id="qSum"></dl><button type="button" class="btn btn-ev" id="qDone" style="width:100%">Close</button>
      </div>
      <p class="sr" id="qLive" aria-live="polite"></p>
    </div></dialog>`;
  }
  const waIcon = `<svg viewBox="0 0 24 24" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><path d="M9.3 8.8c-.3 2.9 2.2 5.4 5.1 5.1l.9-1.4-1.9-1-.8.7a3.2 3.2 0 0 1-1.5-1.5l.7-.8-1-1.9z"/></svg>`;

  /* ---------- page assembly ---------- */
  const app = $("#app");
  app.innerHTML = header() + `<main id="main">` +
    hero() + wave("dark", "cream") + why() + wave("cream", "e50") + services() + wave("e50", "cream", true) +
    pricing() + wave("cream", "dark") + promises() + wave("dark", "cream", true) + results() + wave("cream", "e50") +
    reviews() + wave("e50", "cream", true) + faq() + wave("cream", "e50") + about() + wave("e50", "cream", true) + area() + wave("cream", "dark") +
    finalBand() + line("dark", "deep", true) + `</main>` + footer() +
    `<div class="mbar" id="mbar">${cta()}<a class="mcall" href="tel:${K.phoneHref}" aria-label="Call ${esc(K.phone)}">${icon("phone", 22)}</a></div>` +
    // PLACEHOLDER - replace for real client: WhatsApp number. Generic chat icon used; swap in the official WhatsApp mark if you have the rights to it.
    `<a class="wa" href="https://wa.me/${K.whatsapp}" target="_blank" rel="noopener" aria-label="Chat with ${esc(B.name)} on WhatsApp (opens in a new tab)"><span class="wa-t">Contact us</span><span class="wa-i">${waIcon}</span></a>` +
    dialogHtml();
  document.body.classList.add("has-bar");

  /* =====================================================================
     QUOTE CONNECTOR (mirrors src/lib/quote: schema.ts, adapter.ts, submit.ts)
     Demo adapter only: no network call, nothing stored, nothing logged.
     ===================================================================== */
  const ENUM = { property: PROP_OPTS.map(o => o[0]), insulation: INS_OPTS.map(o => o[0]), work: WORK_OPTS.map(o => o[0]) };
  const PC_RE = /^(GIR0AA|[A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]([0-9ABEHMNPRV-Y])?)|[0-9][A-HJKPSTUW])[0-9][ABD-HJLNP-UW-Z]{2})$/;
  const normalisePostcode = s => { const c = String(s || "").toUpperCase().replace(/[^A-Z0-9]/g, ""); return c.length > 3 ? c.slice(0, -3) + " " + c.slice(-3) : c; };
  const normalisePhone = s => { let d = String(s || "").replace(/[\s\-().]/g, ""); if (d.startsWith("+44")) d = "0" + d.slice(3); else if (d.startsWith("0044")) d = "0" + d.slice(4); return d; };
  const MSG = {
    postcode: { empty: "Enter your postcode.", bad: "That doesn't look like a UK postcode. Try something like NG2 0AB." },
    property: "Choose your property type.", insulation: "Tell us what insulation you have now. \"Not sure\" is fine.", work: "Choose the work you want. \"Not sure\" is fine.",
    name: "Enter your name.", phone: { empty: "Enter a phone number so Pete can ring you.", bad: "That doesn't look like a UK phone number. Try 0115 496 0123 or 07700 900123." }
  };
  /** QuoteRequest schema: returns { success: true, data } or { success: false, errors } like Zod's safeParse. */
  function parseQuote(input, only) {
    const errors = {}, data = {};
    const want = f => !only || only.includes(f);
    if (want("postcode")) { const v = normalisePostcode(input.postcode); if (!v) errors.postcode = MSG.postcode.empty; else if (!PC_RE.test(v.replace(" ", ""))) errors.postcode = MSG.postcode.bad; else data.postcode = v; }
    ["property", "insulation", "work"].forEach(f => { if (want(f)) { if (!ENUM[f].includes(input[f])) errors[f] = MSG[f]; else data[f] = input[f]; } });
    if (want("name")) { const v = String(input.name || "").trim(); if (v.length < 2 || v.length > 80) errors.name = MSG.name; else data.name = v; }
    if (want("phone")) { const raw = String(input.phone || "").trim(); const v = normalisePhone(raw); if (!raw) errors.phone = MSG.phone.empty; else if (!/^0[1237]\d{8,9}$/.test(v)) errors.phone = MSG.phone.bad; else data.phone = v; }
    return Object.keys(errors).length ? { success: false, errors } : { success: true, data };
  }
  class QuoteNetworkError extends Error { constructor() { super("Network unreachable"); this.name = "QuoteNetworkError"; } }
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let failNextDemoSubmit = location.hash === "#demo-error"; // add #demo-error to the page address to preview the error + retry state
  /** QuoteAdapter. Swap in a real adapter (e.g. a free form service) without touching the UI. */
  const demoAdapter = {
    id: "demo",
    async submit(req) {
      await sleep(800); // simulated latency; no fetch, no storage
      if (failNextDemoSubmit) { failNextDemoSubmit = false; throw new QuoteNetworkError(); }
      return { id: "DEMO-" + Math.random().toString(36).slice(2, 8).toUpperCase(), receivedAt: new Date().toISOString(), callbackWindow: "within 2 hours (Mon-Sat)", demo: true };
    }
  };
  /** submitQuote: re-validates, calls the adapter in try/catch, returns a discriminated-union Result. */
  async function submitQuote(input, adapter = demoAdapter) {
    const parsed = parseQuote(input);
    if (!parsed.success) return { ok: false, error: { type: "validation", fieldErrors: parsed.errors } };
    try { return { ok: true, receipt: await adapter.submit(parsed.data) }; }
    catch (e) {
      if (e instanceof QuoteNetworkError) return { ok: false, error: { type: "network", message: "We couldn't reach the server." } };
      return { ok: false, error: { type: "unknown", message: "Something went wrong." } };
    }
  }

  /* ---------- quote popup behaviour ---------- */
  const dlg = $("#quote"), form = $("#qform"), html = document.documentElement;
  const V = { postcode: "", property: "", insulation: "", work: "", name: "", phone: "" };
  const Q = { step: 1, status: "idle", dir: 1 };
  const STEP_FIELDS = { 1: ["property"], 2: ["insulation"], 3: ["work"], 4: ["postcode"], 5: ["name", "phone"] };
  let photoUrl = "", adv = 0, lockY = 0;

  function syncFromDom() {
    V.postcode = $("#qPostcode").value; V.name = $("#qName").value; V.phone = $("#qPhone").value;
    ["property", "insulation", "work"].forEach(n => { const c = $(`input[name="${n}"]:checked`, form); V[n] = c ? c.value : ""; });
  }
  function syncToDom() {
    $("#qPostcode").value = V.postcode; $("#qName").value = V.name; $("#qPhone").value = V.phone;
    ["property", "insulation", "work"].forEach(n => $$(`input[name="${n}"]`, form).forEach(r => { r.checked = r.value === V[n]; }));
  }
  function clearErrors() {
    $$(".field.bad", form).forEach(f => f.classList.remove("bad"));
    $$("[aria-invalid]", form).forEach(i => i.removeAttribute("aria-invalid"));
  }
  function showErrors(errors) {
    clearErrors();
    Object.entries(errors).forEach(([k, msg]) => {
      const f = $(`.field[data-field="${k}"]`, form); if (!f) return;
      f.classList.add("bad"); $(".err span", f).textContent = msg;
      const inp = $("input.input", f); if (inp) inp.setAttribute("aria-invalid", "true");
    });
    const first = $(".field.bad", form);
    if (first) { const t = $("input", first); if (t) t.focus(); }
  }
  function setBanner(error) {
    const b = $("#qBanner");
    if (!error) { b.hidden = true; b.innerHTML = ""; return; }
    b.innerHTML = `<b>${icon("alert", 20)}<span>${error.type === "validation" ? "A few details need fixing." : "We couldn't send that just now."}</span></b>
      <p>${error.type === "validation" ? "Check the highlighted fields and try again." : `Nothing has been lost. Try again, or ring us on <a href="tel:${K.phoneHref}">${esc(K.phone)}</a>.`}</p>
      ${error.type === "validation" ? "" : `<div class="acts"><button type="button" class="btn btn-ev" id="qRetry">Try again</button><a href="tel:${K.phoneHref}">${icon("phone", 16)} ${esc(K.phone)}</a></div>`}`;
    b.hidden = false;
  }
  function render(animate) {
    $$(".pg", form).forEach(p => {
      const on = Number(p.dataset.step) === Q.step;
      p.hidden = !on; p.classList.remove("in-next", "in-prev");
      if (on && animate) { void p.offsetWidth; p.classList.add(Q.dir > 0 ? "in-next" : "in-prev"); }
    });
    $("#qStep").textContent = `Step ${Q.step} of ${TOTAL}`;
    $("#qTitle").textContent = TITLES[Q.step - 1];
    $("#qProg").setAttribute("aria-valuenow", Q.step); $("#qProg").style.setProperty("--prog", Q.step / TOTAL);
    const next = $("#qNext"), back = $("#qBack"), sub = Q.status === "submitting";
    back.hidden = Q.step === 1; back.disabled = sub;
    if (Q.step < TOTAL) { next.className = "btn btn-ev"; next.textContent = "Continue"; next.disabled = false; }
    else if (sub) { next.className = "btn btn-cta"; next.disabled = true; next.innerHTML = `<span class="spin" aria-hidden="true"></span>Sending…`; }
    else { next.className = "btn btn-cta"; next.disabled = false; next.textContent = C.ctaLabel; }
    $("#qBody").scrollTop = 0;
  }
  function goStep(n, dir) { Q.step = n; Q.dir = dir; clearErrors(); render(true); $("#qTitle").focus({ preventScroll: true }); }
  function firstOpen() { for (let s = 1; s <= TOTAL; s++) if (!parseQuote(V, STEP_FIELDS[s]).success) return s; return TOTAL; }

  function resetQuote() {
    Object.keys(V).forEach(k => (V[k] = "")); Q.step = 1; Q.status = "idle";
    syncToDom(); clearErrors(); setBanner(null); form.hidden = false; $("#qOk").hidden = true; clearPhoto(); render(false);
  }
  function clearPhoto() {
    if (photoUrl) { URL.revokeObjectURL(photoUrl); photoUrl = ""; }
    $("#qPhoto").value = ""; $("#qPhotoName").textContent = "Add a photo of your loft"; $("#qPhotoPrev").innerHTML = icon("camera", 28);
  }
  /** Opens the popup in place. The page never scrolls: position is saved and restored. */
  function openQuote() {
    if (Q.status === "success") resetQuote();
    clearTimeout(adv); syncToDom(); setBanner(null);
    Q.status = "idle"; Q.dir = 1; Q.step = firstOpen(); render(false);
    if (!dlg.open) { lockY = window.scrollY; dlg.showModal(); html.classList.add("drawer-open"); window.scrollTo(0, lockY); }
    requestAnimationFrame(() => $("#qTitle").focus({ preventScroll: true }));
  }

  async function runSubmit() {
    syncFromDom(); setBanner(null); Q.status = "submitting"; render(false);
    $("#qLive").textContent = "Sending your request. One moment.";
    const res = await submitQuote({ postcode: V.postcode, property: V.property, insulation: V.insulation, work: V.work, name: V.name, phone: V.phone });
    if (res.ok) {
      Q.status = "success"; $("#qLive").textContent = "";
      const first = V.name.trim().split(/\s+/)[0];
      $("#qThanks").textContent = `Thanks ${first}, Pete will ring you ${res.receipt.callbackWindow}`;
      const label = (list, v) => (list.find(o => o[0] === v) || [v, v])[1];
      $("#qSum").innerHTML = [["Property", label(PROP_OPTS, V.property)], ["Loft insulation now", label(INS_OPTS, V.insulation)], ["Work", label(WORK_OPTS, V.work)], ["Postcode", normalisePostcode(V.postcode)], ["Phone", V.phone]]
        .map(([k, v]) => `<dt>${k}</dt><dd>${esc(v)}</dd>`).join("");
      form.hidden = true; $("#qOk").hidden = false;
      $("#qProg").style.setProperty("--prog", 1); $("#qStep").textContent = "Done"; $("#qTitle").textContent = "Enquiry received";
      $("#qThanks").focus({ preventScroll: true });
    } else {
      Q.status = "error"; $("#qLive").textContent = "";
      if (res.error.type === "validation") {
        const fe = res.error.fieldErrors, step = [1, 2, 3, 4, 5].find(n => STEP_FIELDS[n].some(f => fe[f])) || 1;
        Q.step = step; render(false); setBanner(res.error); showErrors(fe);
      } else { render(false); setBanner(res.error); $("#qBanner").focus(); }
    }
  }
  /** Validates the current page, then opens the next one (or submits on the last page). */
  function advance() {
    syncFromDom();
    const r = parseQuote(V, STEP_FIELDS[Q.step]);
    if (!r.success) { setBanner(null); showErrors(r.errors); return; }
    if (Q.step === 4) { V.postcode = r.data.postcode; $("#qPostcode").value = V.postcode; }
    if (Q.step < TOTAL) { setBanner(null); goStep(Q.step + 1, 1); } else runSubmit();
  }

  form.addEventListener("submit", e => { e.preventDefault(); if (Q.status === "submitting") return; clearTimeout(adv); advance(); });
  // One tap on a choice opens the next page. Keyboard clicks (detail 0) don't auto-advance, so arrow keys can browse options; Enter or Continue moves on.
  form.addEventListener("click", e => {
    const r = e.target.closest('input[type="radio"]');
    if (!r || e.detail === 0 || Q.status !== "idle") return;
    clearTimeout(adv); adv = setTimeout(advance, reduced() ? 0 : 240);
  });
  $("#qBack").addEventListener("click", () => { clearTimeout(adv); setBanner(null); goStep(Q.step - 1, -1); });
  form.addEventListener("input", e => { const f = e.target.closest(".field.bad"); if (f) { f.classList.remove("bad"); const i = $("input.input", f); if (i) i.removeAttribute("aria-invalid"); } });
  $("#qBanner").addEventListener("click", e => { if (e.target.closest("#qRetry")) runSubmit(); });
  $("#qPostcode").addEventListener("blur", e => { if (e.target.value.trim()) e.target.value = normalisePostcode(e.target.value); });
  $("#qPhoto").addEventListener("change", e => {
    const f = e.target.files && e.target.files[0]; if (!f) return clearPhoto();
    if (photoUrl) URL.revokeObjectURL(photoUrl);
    photoUrl = URL.createObjectURL(f); // local preview only; never uploaded
    $("#qPhotoName").textContent = f.name; $("#qPhotoPrev").innerHTML = `<img src="${photoUrl}" alt="">`;
  });
  $("#qClose").addEventListener("click", () => dlg.close());
  $("#qDone").addEventListener("click", () => dlg.close());
  dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });           // backdrop click
  dlg.addEventListener("close", () => { clearTimeout(adv); html.classList.remove("drawer-open"); window.scrollTo(0, lockY); if (Q.status === "submitting") Q.status = "idle"; });

  /* ---------- global click handling: every CTA opens the same popup ---------- */
  document.addEventListener("click", e => {
    if (e.target.closest("[data-open-quote]")) { openQuote(); return; }
    const a = e.target.closest('a[href^="#"]'); if (!a) return;
    e.preventDefault();
    const id = a.getAttribute("href").slice(1); if (!id) return;
    const t = document.getElementById(id); if (!t) return;
    closeMenu(false);
    t.scrollIntoView({ behavior: reduced() ? "auto" : "smooth", block: "start" });
    try { history.replaceState(null, "", "#" + id); } catch (_) { /* sandboxed frame */ }
  });

  /* ---------- header menu ---------- */
  const burger = $("#burger"), menu = $("#menu");
  function closeMenu(returnFocus) {
    if (menu.hidden) return;
    menu.hidden = true; burger.setAttribute("aria-expanded", "false"); burger.setAttribute("aria-label", "Open menu");
    if (returnFocus) burger.focus();
  }
  burger.addEventListener("click", () => {
    const open = menu.hidden; menu.hidden = !open;
    burger.setAttribute("aria-expanded", String(open)); burger.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  });
  document.addEventListener("keydown", e => { if (e.key === "Escape" && !menu.hidden) { e.preventDefault(); closeMenu(true); } });
  document.addEventListener("click", e => { if (!menu.hidden && !e.target.closest(".hdr")) closeMenu(false); });
  document.addEventListener("click", e => { if (e.target.closest("[data-placeholder]")) e.preventDefault(); });
  window.matchMedia("(min-width:1000px)").addEventListener("change", () => closeMenu(false));

  /* ---------- pricing selector ---------- */
  $$('input[name="house"]').forEach(r => r.addEventListener("change", () => {
    const id = r.value, full = C.houseTypes.find(h => h.id === id).full;
    $$("[data-price]").forEach(el => { el.textContent = money(C.prices[id][+el.dataset.price]); el.classList.remove("flash"); void el.offsetWidth; if (!reduced()) el.classList.add("flash"); });
    $$("[data-for]").forEach(el => { el.textContent = `${full}. Fixed price confirmed after your free check.`; });
    $("#priceLive").textContent = `Prices updated for ${full.toLowerCase()}.`;
  }));

  /* ---------- before / after slider ---------- */
  (function () {
    const box = $("#cmp"), rng = $("#cmpRange");
    const set = v => { v = Math.max(0, Math.min(100, Math.round(v))); rng.value = v; box.style.setProperty("--p", v / 100); rng.setAttribute("aria-valuetext", `Divider at ${v}%. Before on the left, after on the right.`); };
    rng.addEventListener("input", () => set(+rng.value));
    let drag = false;
    const fromX = x => { const r = box.getBoundingClientRect(); set(((x - r.left) / r.width) * 100); };
    box.addEventListener("pointerdown", e => { drag = true; box.setPointerCapture(e.pointerId); fromX(e.clientX); rng.focus({ preventScroll: true }); });
    box.addEventListener("pointermove", e => { if (drag) fromX(e.clientX); });
    const end = () => { drag = false; };
    box.addEventListener("pointerup", end); box.addEventListener("pointercancel", end);
    set(50);
  })();

  /* ---------- reviews slider ---------- */
  (function () {
    const root = $("#rv"), track = $("#rvTrack"), cards = $$(".rv-card", track), prev = $("#rvPrev"), next = $("#rvNext"), dots = $("#rvDots");
    const gap = () => parseFloat(getComputedStyle(root).getPropertyValue("--gap")) || 20;
    const step = () => cards[0].getBoundingClientRect().width + gap();
    const pv = () => Math.max(1, Math.round((track.clientWidth + gap()) / step()));
    const maxIdx = () => Math.max(0, cards.length - pv());
    const idx = () => Math.min(maxIdx(), Math.round(track.scrollLeft / step()));
    let tgt = null; // target index while a smooth scroll is in flight, so quick repeat presses stack
    const cur = () => (tgt === null ? idx() : tgt);
    const behavior = () => (reduced() ? "auto" : "smooth");
    const go = i => { tgt = Math.max(0, Math.min(maxIdx(), i)); track.scrollTo({ left: tgt * step(), behavior: behavior() }); };
    function buildDots() { dots.innerHTML = Array.from({ length: maxIdx() + 1 }, (_, i) => `<button type="button" class="dotb" data-i="${i}" aria-label="Go to review ${i + 1}"><i></i></button>`).join(""); update(); }
    function update() {
      if (tgt !== null && Math.abs(track.scrollLeft - tgt * step()) < 2) tgt = null;
      const i = idx();
      prev.disabled = track.scrollLeft <= 2; next.disabled = track.scrollLeft >= track.scrollWidth - track.clientWidth - 2;
      $$(".dotb", dots).forEach((d, k) => d.setAttribute("aria-current", String(k === i)));
    }
    let raf = 0; track.addEventListener("scroll", () => { if (!raf) raf = requestAnimationFrame(() => { raf = 0; update(); }); }, { passive: true });
    prev.addEventListener("click", () => go(cur() - 1)); next.addEventListener("click", () => go(cur() + 1));
    dots.addEventListener("click", e => { const b = e.target.closest(".dotb"); if (b) go(+b.dataset.i); });
    track.addEventListener("keydown", e => { if (e.key === "ArrowRight") { e.preventDefault(); go(cur() + 1); } else if (e.key === "ArrowLeft") { e.preventDefault(); go(cur() - 1); } });
    if ("ResizeObserver" in window) new ResizeObserver(buildDots).observe(track); else window.addEventListener("resize", buildDots);
    buildDots();
  })();

  /* ---------- FAQ accordion ---------- */
  $$(".acc-btn").forEach(b => b.addEventListener("click", () => {
    const open = b.getAttribute("aria-expanded") === "true", p = document.getElementById(b.getAttribute("aria-controls"));
    b.setAttribute("aria-expanded", String(!open)); p.classList.toggle("open", !open);
    if (open) p.setAttribute("inert", ""); else p.removeAttribute("inert");
  }));

  /* ---------- motion helpers: one shared IntersectionObserver + one pointer handler ---------- */
  if ("IntersectionObserver" in window) {
    const io = new IntersectionObserver(es => es.forEach(en => en.target.classList.toggle("is-paused", !en.isIntersecting)), { rootMargin: "100px" });
    $$(".ambient,.divider.wave").forEach(el => io.observe(el));
    if (!reduced()) {
      const lines = $$(".divider.line");
      lines.forEach(l => l.classList.add("pre"));
      const lio = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { en.target.classList.remove("pre"); en.target.classList.add("go"); lio.unobserve(en.target); } }), { threshold: 0.6 });
      lines.forEach(l => lio.observe(l));
    }
    /* mobile sticky bar: shows once the hero has scrolled out of view */
    const mbar = $("#mbar"); let pulsed = false;
    new IntersectionObserver(([en]) => {
      const past = !en.isIntersecting && en.boundingClientRect.top < 0;
      mbar.classList.toggle("show", past);
      if (past && !pulsed) { pulsed = true; mbar.classList.add("pulse"); setTimeout(() => mbar.classList.remove("pulse"), 1400); }
    }).observe($("#top"));
  }
  let pmRaf = 0, pm = null;
  document.addEventListener("pointermove", e => {
    if (e.pointerType === "touch") return;
    const b = e.target.closest && e.target.closest(".btn-cta"); if (!b) return;
    pm = { b, x: e.clientX, y: e.clientY };
    if (!pmRaf) pmRaf = requestAnimationFrame(() => { pmRaf = 0; const r = pm.b.getBoundingClientRect(); pm.b.style.setProperty("--mx", (pm.x - r.left) + "px"); pm.b.style.setProperty("--my", (pm.y - r.top) + "px"); });
  }, { passive: true });
})();
