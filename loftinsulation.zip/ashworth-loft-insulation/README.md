# Ashworth Loft Insulation (demo site)

A single-page, fictional UK loft-insulation website. The finished page is `index.html`: one self-contained file with all CSS, JS and images inlined. It needs no build step to view or host.

## View or host
- Open `index.html` in a browser, or
- On GitHub: Settings -> Pages -> deploy from the `main` branch, root folder.

## Edit
The source lives in `src/`:
- `config.js` - all site content (text, prices, towns, contact details, CTA label)
- `app.js` - section renderers and behaviour (quote popup, sliders, FAQ)
- `art.js` - image manifest and SVG illustrations
- `style.css` - all styles
- `*.b64` - base64 photos (hero, owner, heat-loss, before, after) injected at build time

Rebuild after editing: `python3 build.py` (rewrites `index.html`).

## Tests (optional, dev only)
`tests/check.py` (and `tests/responsive.py`) run Playwright checks (CTA count, popup flow, no horizontal overflow, etc.).
`pip install playwright && playwright install chromium`, then `python3 tests/check.py`.

## Placeholders to replace for a real client
- Phone `+44 7340 842540` and the WhatsApp number (in `config.js`)
- All photos (supplied demo images) and the business details (fictional)
- The quote popup is demo-only: it sends nothing anywhere. Connect a real backend in the connector section of `app.js`.
- The WhatsApp button uses a generic chat icon, not the official WhatsApp logo.
