# Dev-only: screenshots each width and asserts no horizontal overflow. Not shipped.
import sys, json
from playwright.sync_api import sync_playwright
URL = "file:///home/claude/ashworth/index.html"
WIDTHS = [375, 390, 430, 768, 1024, 1440, 1920]
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    for w in WIDTHS:
        ctx = b.new_context(viewport={"width": w, "height": 900 if w > 600 else 800}, device_scale_factor=1)
        pg = ctx.new_page(); errs = []
        pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
        pg.on("pageerror", lambda e: errs.append(str(e)))
        pg.goto(URL); pg.wait_for_timeout(500)
        H = pg.evaluate("document.documentElement.scrollHeight")
        for y in range(0, H, 600):
            pg.evaluate(f"window.scrollTo(0,{y})"); pg.wait_for_timeout(40)
        pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300)
        r = pg.evaluate("""() => ({sw: document.documentElement.scrollWidth, iw: window.innerWidth,
            wide: [...document.querySelectorAll('body *')].filter(e => {const r=e.getBoundingClientRect(); return r.width>0 && r.right>window.innerWidth+1 && !e.closest('.ambient') && !e.closest('.divider') && !e.closest('.rv-track') && !e.closest('dialog')}).slice(0,5).map(e=>e.tagName+'.'+e.className)})""")
        print(w, "overflow" if r["sw"] > r["iw"] else "ok", r, errs[:3])
        pg.screenshot(path=f"/home/claude/ashworth/shots/full-{w}.png", full_page=True)
        ctx.close()
    b.close()
