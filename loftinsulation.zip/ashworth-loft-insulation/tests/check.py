import sys, re
from playwright.sync_api import sync_playwright
URL="file:///home/claude/ashworth/index.html"
fails=[]
def ok(c,m):
    print(("PASS " if c else "FAIL ")+m)
    if not c: fails.append(m)
with sync_playwright() as p:
    b=p.chromium.launch()
    for name,w,h in (("desktop",1440,900),("mobile",390,844)):
        pg=b.new_page(viewport={"width":w,"height":h}); net=[]
        pg.on("request",lambda r:net.append(r.url) if not r.url.startswith(("file:","data:","blob:")) and "fonts.g" not in r.url else None)
        pg.goto(URL); pg.wait_for_timeout(400)
        ok(pg.evaluate("document.documentElement.scrollWidth<=innerWidth"),f"{name}: no h-overflow")
        n=pg.locator("[data-open-quote]:not(#mbar *)").count(); ok(n==2,f"{name}: 2 CTAs outside bar (got {n})")
        ok(pg.locator("#top input, #top form").count()==0,f"{name}: hero has no postcode/form")
        ok(pg.locator("header .btn-cta, .hdr .btn-cta").count()==0,f"{name}: header no CTA")
        txt=pg.inner_text("body").lower()
        ok("prices are guides" not in txt,f"{name}: no pricing disclaimer")
        ok("4.9" not in pg.inner_text("#reviews") and "fictional" not in pg.inner_text("#reviews").lower(),f"{name}: reviews header gone")
        ok(pg.locator("#reviews svg[aria-hidden]").count()>=0,"")
        ok(not re.search(r"\d+\s*(–\s*\d+\s*)?of\s*\d+",pg.inner_text("#reviews")),f"{name}: no '1 of 6' text")
        ok(pg.locator("#area .towns li").count()==6 and pg.locator("#area svg.map, #area .map").count()==0,f"{name}: area 6 towns, no map")
        ok("areas covered" not in txt and "0115" not in txt and "accreditation" not in pg.inner_text("footer.foot").lower(),f"{name}: footer cleaned")
        ok("+44 7340 842540" in pg.inner_text("footer.foot"),f"{name}: footer new number")
        ok(pg.locator('a[href="tel:+447340842540"]').count()>0,f"{name}: tel link updated")
        # reviews controls centred below
        pb=pg.locator("#rvTrack").bounding_box(); cb=pg.locator(".rv-ctl").bounding_box()
        ok(cb["y"]>=pb["y"]+pb["height"]-4 and abs((cb["x"]+cb["width"]/2)-(pb["x"]+pb["width"]/2))<30,f"{name}: slider controls below + centred")
        pg.locator("#rvNext").click(); pg.wait_for_timeout(500); ok(pg.evaluate("document.querySelector('#rvTrack').scrollLeft")>0,f"{name}: next works")
        # wa + mbar
        ok(pg.locator(".wa").is_visible()==(name=="desktop"),f"{name}: whatsapp visibility")
        # popup flow
        y0=800; pg.evaluate(f"window.scrollTo(0,{y0})"); pg.wait_for_timeout(200)
        pg.evaluate("document.documentElement.style.scrollBehavior='auto'")
        pg.evaluate("document.querySelector('#top [data-open-quote]').click()"); pg.wait_for_timeout(500)
        ok(pg.locator("dialog#quote[open]").count()==1,f"{name}: popup opens")
        ok(abs(pg.evaluate("scrollY")-y0)<3,f"{name}: scroll unchanged ({pg.evaluate('scrollY')})")
        if name=="desktop": pg.screenshot(path="/tmp/s_pop1.png")
        pg.locator("#quote .tile").first.click(); pg.wait_for_timeout(600)
        ok("2 of 5" in pg.inner_text("#qStep").lower(),f"{name}: auto-advance to 2")
        pg.locator('#quote input[name=insulation]').first.click(); pg.wait_for_timeout(600)
        pg.locator('#quote input[name=work]').first.click(); pg.wait_for_timeout(600)
        ok("4 of 5" in pg.inner_text("#qStep").lower(),f"{name}: at step 4")
        if name=="mobile": pg.screenshot(path="/tmp/s_pop4m.png")
        pg.click("#qNext"); pg.wait_for_timeout(200); ok(pg.locator(".field.bad").count()==1,f"{name}: empty postcode error")
        pg.fill("#qPostcode","ng20ab"); pg.click("#qNext"); pg.wait_for_timeout(500)
        ok("5 of 5" in pg.inner_text("#qStep").lower(),f"{name}: step 5")
        pg.click("#qBack"); pg.wait_for_timeout(300); ok("4 of 5" in pg.inner_text("#qStep").lower(),f"{name}: back")
        pg.click("#qNext"); pg.wait_for_timeout(400)
        pg.fill("#qName","Sam Jones"); pg.fill("#qPhone","12"); pg.click("#qNext"); pg.wait_for_timeout(200)
        ok(pg.locator(".field.bad").count()==1,f"{name}: bad phone error")
        pg.fill("#qPhone","07340 842540"); pg.click("#qNext"); pg.wait_for_timeout(1500)
        ok("Thanks Sam, Pete will ring you within 2 hours" in pg.inner_text("#qThanks"),f"{name}: success copy: {pg.inner_text('#qThanks')}")
        ok(not net,f"{name}: no network {net}")
        pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
        ok(abs(pg.evaluate("scrollY")-y0)<3,f"{name}: scroll restored")
        # screenshots
        for sid in ("promises","faq","area","reviews"):
            pg.locator("#"+sid).scroll_into_view_if_needed(); pg.wait_for_timeout(400)
            pg.locator("#"+sid).screenshot(path=f"/tmp/s_{name}_{sid}.png")
        pg.evaluate("window.scrollTo(0,0)"); pg.wait_for_timeout(300); pg.screenshot(path=f"/tmp/s_{name}_top.png")
        pg.evaluate("window.scrollTo(0,document.body.scrollHeight)"); pg.wait_for_timeout(400); pg.screenshot(path=f"/tmp/s_{name}_bot.png")
        print(name,"section heights", pg.evaluate("['promises','faq','area'].map(i=>Math.round(document.getElementById(i).offsetHeight))"))
    for w in (375,430,768,1024,1920):
        pg=b.new_page(viewport={"width":w,"height":800}); pg.goto(URL); pg.wait_for_timeout(200)
        ok(pg.evaluate("document.documentElement.scrollWidth<=innerWidth"),f"{w}: no h-overflow")
    b.close()
print("FAILS:",fails); sys.exit(1 if fails else 0)
