import pathlib
r=pathlib.Path(__file__).parent/'src'
css=(r/'style.css').read_text().replace('__HERO_IMG__',(r/'hero.b64').read_text().strip()); js=(r/'config.js').read_text()+'\n'+(r/'art.js').read_text().replace('__PETE_IMG__',(r/'pete.b64').read_text().strip()).replace('__BEFORE_IMG__',(r/'before.b64').read_text().strip()).replace('__AFTER_IMG__',(r/'after.b64').read_text().strip())+'\n'+(r/'app.js').read_text().replace('__WHY_IMG__',(r/'whyimg.b64').read_text().strip())
html=f'''<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Ashworth Loft Insulation</title>
<meta name="description" content="Fixed-price loft insulation in Nottingham, fitted in one day. Fictional demonstration site.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
{css}
</style>
</head>
<body>
<a class="skip" href="#main">Skip to content</a>
<div id="app"></div>
<noscript><p style="padding:24px">This demonstration site needs JavaScript to display its content.</p></noscript>
<script>
{js}
</script>
</body>
</html>
'''
(pathlib.Path(__file__).parent/'index.html').write_text(html)
print(len(html)//1024,'KB')
